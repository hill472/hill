package com.example.javaWeb;

import com.example.javaWeb.mapper.BaseExampleMapper;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.TestPropertySource;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import javax.annotation.Resource;

@SpringBootTest(classes = JavaWebApplication.class)
@RunWith(SpringJUnit4ClassRunner.class)
@TestPropertySource(properties = {"spring.profiles.active=dev"})
public class JavaWebApplicationTest {

    @Resource
    private BaseExampleMapper exampleMapper;

    @Test
    public void testGetInteractionDetails() {
        exampleMapper.getInteractionDetails().forEach(System.out::println);
    }

}
