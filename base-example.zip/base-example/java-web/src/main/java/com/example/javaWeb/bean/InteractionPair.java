package com.example.javaWeb.bean;

import lombok.Data;

@Data
public class InteractionPair {

    private String u1;
    private String u2;
    private Integer u1Cnt;
    private Integer u2Cnt;
    private Integer interactCnt;

}
