package com.example.javaWeb.mapper;

import com.example.javaWeb.bean.InteractionDetail;
import com.example.javaWeb.bean.InteractionPair;
import org.apache.ibatis.annotations.Mapper;
import org.springframework.stereotype.Repository;

import java.util.List;

@Mapper
@Repository
public interface BaseExampleMapper {

    List<InteractionDetail> getInteractionDetails();

    List<InteractionPair> getInteractionPairs();

}
