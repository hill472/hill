package com.example.javaWeb.conf;

import com.alibaba.druid.pool.DruidDataSource;
import com.alibaba.druid.spring.boot.autoconfigure.DruidDataSourceBuilder;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;


@Configuration
public class DataSourceConf {

    @Value("${spring.datasource.url}")
    private String baseJdbcUrl;
    @Value("${spring.datasource.username}")
    private String baseUsername;
    @Value("${spring.datasource.password}")
    private String basePwd;


    @Bean(initMethod = "init", name = "baseSource", destroyMethod = "close")
    @ConfigurationProperties(prefix = "spring.datasource.druid.common")
    public DruidDataSource baseDataSource() {
        return createDataSource(baseJdbcUrl, baseUsername, basePwd);
    }

    private DruidDataSource createDataSource(String url, String username, String pwd) {
        DruidDataSource druidDataSource = DruidDataSourceBuilder.create().build();
        druidDataSource.setUrl(url);
        druidDataSource.setUsername(username);
        druidDataSource.setPassword(pwd);
        return druidDataSource;
    }

}

