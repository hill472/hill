package com.example.javaWeb.controller;

import com.example.javaWeb.bean.InteractionDetail;
import com.example.javaWeb.bean.InteractionPair;
import com.example.javaWeb.mapper.BaseExampleMapper;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.annotation.Resource;
import java.util.List;

@RestController
@RequestMapping("/base/example/java-web")
public class BaseExampleController {

    @Resource
    private BaseExampleMapper exampleMapper;

    @GetMapping("/interaction/detail")
    public List<InteractionDetail> getInteractionDetails() {
        return exampleMapper.getInteractionDetails();
    }

    @GetMapping("/interaction/pairs")
    public List<InteractionPair> getInteractionPairs() {
        return exampleMapper.getInteractionPairs();
    }

}
