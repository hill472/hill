package com.example.javaWeb.bean;

import lombok.Data;

@Data
public class InteractionDetail {

    private Long id;
    private String userId;
    private String toUserId;
    private String createTime;

}
