package org.example.javaBase;

import java.util.concurrent.atomic.AtomicInteger;

public class CasExample {
    // 创建一个 AtomicInteger，保证多线程操作下数值的原子性
    private static AtomicInteger atomicInt = new AtomicInteger(0);

    public static void main(String[] args) throws InterruptedException {
        // 示例线程，尝试将 atomicInt 从 0 增加到 1
        Thread thread1 = new Thread(() -> {
            // compareAndSet(expectedValue, newValue)，如果 atomicInt 是 expectedValue，则更新为 newValue
            boolean success = atomicInt.compareAndSet(0, 1);
            System.out.println("Thread 1: " + (success ? "成功将值更新为 1" : "在尝试更新时失败"));
        });

        // 示例线程，尝试将 atomicInt 从 0 增加到 2
        Thread thread2 = new Thread(() -> {
            try {
                Thread.sleep(100); // 确保 thread1 先执行
                boolean success = atomicInt.compareAndSet(0, 2);
                System.out.println("Thread 2: " + (success ? "成功将值更新为 2" : "在尝试更新时失败"));
            } catch (Exception e) {
                e.printStackTrace();
            }
        });

        thread1.start();
        thread2.start();

        thread1.join();
        thread2.join();

        // 输出最终的 atomicInt 值
        System.out.println("最终的值: " + atomicInt.get());
    }
}