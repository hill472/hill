package org.example.javaBase;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.*;

public class ThreadPoolExecutorExample {

    private static final ThreadPoolExecutor exPool = new ThreadPoolExecutor(
            5,
            10,
            2,
            TimeUnit.MINUTES,
            new ArrayBlockingQueue<>(10)
    );

    public static void main(String[] args) {
        //有返回值
        List<Future<Integer>> futures = new ArrayList<>();
        for (int i = 1; i <= 10; i++) {
            Future<Integer> future = exPool.submit(() -> {
                int sum = 0;
                for (int j = 1; j <= 10; j++) {
                    sum+=j;
                }
                return sum;
            });
            futures.add(future);
        }

        int total = 0;
        for (Future<Integer> future : futures) {
            try {
                total += future.get();
            } catch (InterruptedException | ExecutionException e) {
                e.printStackTrace();
            }

        }

        System.out.println(total);
        exPool.shutdown();
    }

}
