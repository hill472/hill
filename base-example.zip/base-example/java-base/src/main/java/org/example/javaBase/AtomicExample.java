package org.example.javaBase;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.*;
import java.util.concurrent.atomic.AtomicInteger;

public class AtomicExample {

    private static final AtomicInteger A1 = new AtomicInteger(0);
    private static final AtomicInteger A2 = new AtomicInteger(0);
    private static final ExecutorService exPool = Executors.newFixedThreadPool(10);
    public static final CountDownLatch latch = new CountDownLatch(10);

    private static void sumA1() {
        List<Future<?>> futures = new ArrayList<>();
        for (int i = 0; i < 10; i++) {
            Future<?> future = exPool.submit(() -> {
                for (int j = 0; j < 10; j++) {
                    A1.incrementAndGet();
                }
            });
            futures.add(future);
        }

        for (Future<?> future : futures) {
            try {
                future.get();
            } catch (InterruptedException | ExecutionException e) {
                e.printStackTrace();
            }
        }
        System.out.println("A1 = " + A1);
        exPool.shutdown();
    }

    private static void sumA2() {
        for (int i = 0; i < 10; i++) {
            new Thread(() -> {
                for (int j = 0; j < 10; j++) {
                    A2.incrementAndGet();
                }
                latch.countDown();
            }).start();
        }

        try {
            latch.await();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        System.out.println("A2 = " + A2);
    }

    public static void main(String[] args) {
        sumA1();
        sumA2();
    }

}
