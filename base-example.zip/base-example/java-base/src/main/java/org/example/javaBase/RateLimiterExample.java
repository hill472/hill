package org.example.javaBase;

import com.google.common.util.concurrent.RateLimiter;

public class RateLimiterExample {

    // 每秒只发放1个令牌
    private static RateLimiter rateLimiter = RateLimiter.create(1.0);

    public static void main(String[] args) {
        for (int i = 0; i < 10; i++) {
            // 模拟请求处理
            new Thread(RateLimiterExample::handleRequest).start();
        }
    }

    private static void handleRequest() {
        // 尝试获得令牌
        if (rateLimiter.tryAcquire()) {
            // 处理请求
            System.out.println(Thread.currentThread().getName() + ": 请求成功处理 - " + System.currentTimeMillis());
        } else {
            // 限流操作，可以选择降级处理或返回错误
            System.err.println(Thread.currentThread().getName() + ": 请求被限流 - " + System.currentTimeMillis());
        }
    }
}

