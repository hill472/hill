package org.example.algorithm;

import lombok.Data;

@Data
public class BitMap {

    private int size;
    private int[] bitMap;

    public BitMap(int size) {
        this.size = size;
        bitMap = new int[size]; //初始化一个长度为32*size的bit数组
    }

    //i在对应位图中的位置置为1
    public void add(int i) {
        int arrIndex = i / 32; //i在数组中的索引位置
        int bitIndex = i % 32; //对应数组元素中32位中的位索引
        bitMap[arrIndex] = bitMap[arrIndex] | (1 << bitIndex);
    }

    //i在对应位图中的位置置为0
    public void delete(int i) {
        int arrIndex = i / 32; //i在数组中的索引位置
        int bitIndex = i % 32; //对应数组元素中32位中的位索引
        bitMap[arrIndex] = bitMap[arrIndex] & (~(1 << bitIndex));
    }

    //获取第i位的状态值
    public int get(int i) {
        int arrIndex = i / 32; //i在数组中的索引位置
        int bitIndex = i % 32; //对应数组元素中32位中的位索引
        return (bitMap[arrIndex] >> bitIndex) & 1;
    }

    //判断i是否存在于位图中
    public boolean exist(int i) {
        return get(i) == 1;
    }

    private String intTo32BitBinary(int num) {
        String binaryString = Integer.toBinaryString(num);
        StringBuilder sb = new StringBuilder();
        for (int i = binaryString.length(); i < 32; i++) {
            sb.append("0");
        }
        sb.append(binaryString);
        return sb.toString();
    }

    public void print() {
        for (int i : bitMap) {
            System.out.println(intTo32BitBinary(i));
        }
    }

    public static void main(String[] args) {
        BitMap bitMap = new BitMap(10);
        for (int i = 0; i < 10; i++) {
            bitMap.add(i);
        }

        System.out.println(bitMap.exist(9));

        bitMap.delete(9);
        System.out.println(bitMap.exist(9));
        System.out.println(bitMap.exist(10));
    }
}
