package org.example.algorithm;

import org.apache.commons.lang3.StringUtils;

import java.util.Arrays;
import java.util.List;

/**
 * 查找两个字符串a,b中的最长公共子串。若有多个，输出在较短串中最先出现的那个。
 * 注：子串的定义：将一个字符串删去前缀和后缀（也可以不删）形成的字符串。请和“子序列”的概念分开！
 * 数据范围：字符串长度1≤length≤300
 * 输入描述：输入两个字符串
 * 输出描述：返回重复出现的字符
 */
public class FindLongestCommonSubstring {

    private static String getSolution(String s1, String s2) {
        if (StringUtils.isEmpty(s1) || StringUtils.isEmpty(s2)) {
            return null;
        }

        int n = Math.min(s1.length(), s2.length());
        int m = Math.max(s1.length(), s2.length());
        String shortStr = s1.length() < s2.length() ? s1 : s2;
        String longStr = s2.length() > s1.length() ? s2 : s1;

        // dp[i][j]表示以shortStr[i]和longStr[j]结尾的公共子串的长度
        int[][] dp = new int[n][m];
        for (int i = 0; i < m; i++) {
            if (shortStr.charAt(0) == longStr.charAt(i)) {
                dp[0][i] = 1;
            }
        }

        for (int i = 0; i < n; i++) {
            if (shortStr.charAt(i) == longStr.charAt(0)) {
                dp[i][0] = 1;
            }
        }

        int maxLen = 0; // 记录最长公共子串的长度
        int endIndex = 0; // 记录最长公共子串在a中的结束位置
        for (int i = 1; i < n; i++) {
            for (int j = 1; j < m; j++) {
                if (shortStr.charAt(i) == longStr.charAt(j)) {
                    dp[i][j] = dp[i - 1][j - 1] + 1;
                    if (dp[i][j] > maxLen) {
                        maxLen = dp[i][j];
                        endIndex = i;
                    }
                }
            }

        }
        for (int[] ints : dp) {
            System.out.println(Arrays.toString(ints));
        }
        System.out.println(maxLen);
        return shortStr.substring(endIndex - maxLen + 1, endIndex + 1);
    }

    public static void main(String[] args) {
        String a = "abc";
        String b = "abdfbc";
        System.out.println(getSolution(a, b));
    }

}
