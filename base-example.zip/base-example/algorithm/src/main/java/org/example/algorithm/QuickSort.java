package org.example.algorithm;

/**
 * 开辟两个区域<num）=num（>num
 * 若cur指向的当前元素小于num，则与less指向的后一个元素交换，less和cur向后移动一步
 * 若cur指向的当前元素等于num，cur向后移动一步
 * 若cur指向的当前元素大于num，与more指向的前一个元素交换，more向前移动一步
 * 交换后cur指向的元素继续重复上述步骤，直到cur与more相遇结束。
 * 时间复杂度：O(nlogn)
 * 空间复杂度：O(nlogn)
 */
public class QuickSort {

    // 快速排序的入口方法
    public static void quickSort(int[] arr, int begin, int end) {
        if (begin < end) {
            int[] p = partition(arr, begin, end);

            quickSort(arr, begin, p[0]);  // 递归排序基准左边的子数组
            quickSort(arr, p[1], end);    // 递归排序基准右边的子数组
        }
    }

    private static void swap(int[] arr, int i, int j) {
        int tmp = arr[i];
        arr[i] = arr[j];
        arr[j] = tmp;
    }

    // 分区操作，选择一个基准，将小于基准的元素放到基准左边，大于基准的元素放到基准右边

    /**
     * 开辟两个区域<num）=num（>num
     * 若cur指向的当前元素小于num，则与less指向的后一个元素交换，less和cur向后移动一步
     * 若cur指向的当前元素等于num，cur向后移动一步
     * 若cur指向的当前元素大于num，与more指向的前一个元素交换，more向前移动一步
     * 交换后cur指向的元素继续重复上述步骤，直到cur与more相遇结束。
     * 时间复杂度：O(nlogn)
     * 空间复杂度：O(nlogn)
     */
    private static int[] partition(int[] nums, int start, int end) {
        int less = start - 1;
        int more = end + 1;
        int cur = start;
        while (cur < more) {
            if (nums[cur] < nums[end]) {
                swap(nums, less + 1, cur);
                less++;
                cur++;
            } else if (nums[cur] > nums[end]) {
                swap(nums, cur, more - 1);
                more--;
            } else {
                cur++;
            }
        }
        return new int[]{less, more};
    }

    // 主方法，用于测试
    public static void main(String[] args) {
        int[] input = {3, 1, 0, 2};
        quickSort(input, 0, input.length - 1);
        // 输出排序后的数组
        for (int i : input) {
            System.out.print(i + " ");
        }
    }
}

