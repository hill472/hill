package org.example.algorithm;

import java.util.Arrays;
import java.util.Scanner;

public class Knapsack01 {

    static class Item {
        private int weight; //重量
        private int value; //价值

        public Item() {
        }

        public Item(int w, int v) {
            this.weight = w;
            this.value = v;
        }
    }

    /**
     * 使用动态规划解决0-1背包问题
     *
     * @param weight 背包的最大承重
     * @param num    物品的重量数组
     * @param items  物品数组
     * @return 返回最大价值
     */
    public static int knapsack(int num, int weight, Item[] items) {
        // dp[i][w] 表示在前i个物品内，背包容量为w时的最大价值
        int[][] dp = new int[num + 1][weight + 1];

        // 初始化dp数组
        for (int i = 1; i <= num; i++) {
            for (int j = 1; j <= weight; j++) {
                dp[i][j] = dp[i - 1][j];
                if (j - items[i].weight >= 0)
                    dp[i][j] = Math.max(dp[i][j], dp[i - 1][j - items[i].weight] + items[i].value);
            }
        }
        return dp[num][weight]; // 返回最大价值
    }

    //    6 3
    //    4 1
    //    5 7
    //    2 9
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int weight = scanner.nextInt(); // 背包的承重
        int num = scanner.nextInt(); // 物品数量
        Item[] items = new Item[num + 1];
        for (int i = 0; i < items.length; i++) {
            items[i] = new Item();
        }

        for (int i = 1; i <= num; i++) {
            items[i].weight = scanner.nextInt(); // 物品的重量
            items[i].value = scanner.nextInt(); // 物品的价值
        }

        System.out.println(knapsack(num, weight, items));
    }
}

