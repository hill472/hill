package org.example.algorithm;

/**
 * 寻找重复数
 * 给定一个包含n+1个整数的数组nums，其数字都在[1,n]范围内(包括1和n)，可知至少存在一个重复的整数。
 * 假设nums只有一个重复的整数，返回这个重复的数
 * 你设计的解决方案必须不修改数组nums且只用常量级O(1)的额外空间
 * 示例 1：
 * 输入：nums = [1,3,4,2,2]
 * 输出：2
 * 示例 2：
 * 输入：nums = [3,1,3,4,2]
 * 输出：3
 * 示例 3 :
 * 输入：nums = [3,3,3,3,3]
 * 输出：3
 */
public class FindDuplicatedNum {

    private static void swap(int[] arr, int i, int j) {
        int tmp = arr[i];
        arr[i] = arr[j];
        arr[j] = tmp;
    }

    public static int getSolution(int[] arr) {
        for (int i = 0; i < arr.length; i++) {
            while (arr[i] != arr[arr[i] - 1]) {
                swap(arr, i, arr[i] - 1);
            }
        }

        for (int i = 0; i < arr.length; i++) {
            if (arr[i] != i + 1) {
                return arr[i];
            }
        }
        return -1;
    }

    public static void main(String[] args) {
        int[] arr = {1, 3, 4, 2, 2};
        System.out.println(getSolution(arr));
    }
}
