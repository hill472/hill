package org.example.algorithm;

import java.util.LinkedList;
import java.util.Queue;

/**
 * 3 5 2
 * ..#EE
 * E.#E.
 * ###..
 * 有一个大小是N*M的战场地图，被墙壁 ‘#’ 分隔成大小不同的区域
 * 上下左右四个方向相邻的空地 ‘.’ 属于同一个区域，只有空地上可能存在敌人’E”，
 * 请求出地图上总共有多少区域里的敌人数小于K。
 */
public class FindEnemy {

    private final static int n = 3; //地图的行数
    private final static int m = 5; //地图的列数
    private final static int k = 2; //目标敌人数量
    private final static char[][] matrix; // 定义存储地图的二维字符数组
    private static boolean[][] visited; // 定义标记访问状态的二维数组
    private static int enemyCount; // 记录当前区域的敌人数量
    private static final int[][] dirs = {{0, 1}, {0, -1}, {1, 0}, {-1, 0}};

    static {
        matrix = new char[n][m];
        matrix[0] = "..#EE".toCharArray();
        matrix[1] = "E.#E.".toCharArray();
        matrix[2] = "###..".toCharArray();
        visited = new boolean[n][m];
    }

    private static void bfsFindPath(int i, int j) {
        Queue<int[]> queue = new LinkedList<>();
        queue.add(new int[]{i, j});
        visited[i][j] = true;
        while (!queue.isEmpty()) {
            int[] cur = queue.poll();
            if (matrix[cur[0]][cur[1]] == 'E') {
                enemyCount++;
            }

            for (int[] dir : dirs) {
                int newX = cur[0] + dir[0];
                int newY = cur[1] + dir[1];
                if (newX >= 0 && newX < n
                        && newY >= 0 && newY < m
                        && !visited[newX][newY]
                        && matrix[newX][newY] != '#') {
                    visited[newX][newY] = true;
                    queue.add(new int[]{newX, newY});
                }
            }
        }
    }

    public static void main(String[] args) {
        int cnt = 0;
        for (int i = 0; i < n; i++) {
            for (int j = 0; j < m; j++) {
                if (visited[i][j] || matrix[i][j] == '#')
                    continue;
                enemyCount = 0;
                bfsFindPath(i, j);
                if (enemyCount < k) cnt++;
            }
        }
        System.out.println(enemyCount);
    }

}
