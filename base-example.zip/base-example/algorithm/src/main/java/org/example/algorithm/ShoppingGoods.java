package org.example.algorithm;

import java.util.Scanner;

public class ShoppingGoods {

    static class Good {
        private int cost; //价格
        private int value; //价值
        private boolean main;
        private int a1;  //定义附件1的编号
        private int a2;  //定义附件2的编号

        public Good() {
        }

        public Good(int cost, int value) {
            this.cost = cost;
            this.value = value;
        }

        @Override
        public String toString() {
            return "Good{" +
                    "cost=" + cost +
                    ", value=" + value +
                    ", main=" + main +
                    ", a1=" + a1 +
                    ", a2=" + a2 +
                    '}';
        }
    }

    public static int knapSack(int num, int money, Good[] goods) {
        int[][] dp = new int[num + 1][money + 1];
        for (int i = 1; i <= num; i++) {
            for (int j = 1; j <= money; j++) {
                dp[i][j] = dp[i - 1][j];

                //附件跳过
                if (!goods[i].main) {
                    continue;
                }

                // 购买主件
                if (j - goods[i].cost >= 0) {
                    dp[i][j] = Math.max(dp[i][j], dp[i - 1][j - goods[i].cost] + goods[i].value);

                    // 购买主件，a1
                    if (goods[i].a1 > 0 && j - goods[i].cost - goods[goods[i].a1].cost >= 0) {
                        dp[i][j] = Math.max(dp[i][j],
                                dp[i - 1][j - goods[i].cost - goods[goods[i].a1].cost]
                                        + goods[i].value
                                        + goods[goods[i].a1].value);
                    }
                    // 购买主件，a2
                    if (goods[i].a2 > 0 && j - goods[i].cost - goods[goods[i].a2].cost >= 0) {
                        dp[i][j] = Math.max(dp[i][j],
                                dp[i - 1][j - goods[i].cost - goods[goods[i].a2].cost]
                                        + goods[i].value
                                        + goods[goods[i].a2].value);
                    }
                    // 购买主件，a1，a2
                    if (goods[i].a1 > 0 && goods[i].a2 > 0 && j - goods[i].cost - goods[goods[i].a1].cost - goods[goods[i].a2].cost >= 0) {
                        dp[i][j] = Math.max(dp[i][j],
                                dp[i - 1][j - goods[i].cost - goods[goods[i].a1].cost - goods[goods[i].a2].cost]
                                        + goods[i].value
                                        + goods[goods[i].a1].value
                                        + goods[goods[i].a2].value);
                    }
                }


            }
        }
        return dp[num][money];
    }

    //2000 10
    //500 1 0
    //400 4 0
    //300 5 1
    //400 5 1
    //200 5 0
    //500 4 5
    //400 4 0
    //320 2 0
    //410 3 0
    //400 3 5
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int money = scanner.nextInt(); // 总钱数
        int num = scanner.nextInt(); // 可购买物品的个数
        Good[] goods = new Good[num + 1];
        for (int i = 0; i < goods.length; i++)
            goods[i] = new Good();

        // 读入商品信息
        for (int i = 1; i <= num; i++) {
            int v = scanner.nextInt(); // 价格
            int p = scanner.nextInt(); // 重要度
            int q = scanner.nextInt(); // 主件编号
            goods[i].cost = v;
            goods[i].value = v * p;
            if (q == 0) {
                goods[i].main = true;
            } else if (q > 0 && goods[q].a1 == 0) {
                goods[q].a1 = i;
            } else if (q > 0 && goods[q].a2 == 0) {
                goods[q].a2 = i;
            }
        }
        System.out.println(knapSack(num, money, goods));
    }

}
