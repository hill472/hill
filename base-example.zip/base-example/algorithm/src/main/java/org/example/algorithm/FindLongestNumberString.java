package org.example.algorithm;

import java.util.Scanner;

/**
 * 描述
 * 输入一个字符串，返回其最长的数字子串，以及其长度。
 * 若有多个最长的数字子串，则将它们全部输出（按原字符串的相对位置）
 * 本题含有多组样例输入。
 * 数据范围：字符串长度1≤n≤200 ， 保证每组输入都至少含有一个数字
 * 输入描述：输入一个字符串。1<=len(字符串)<=200
 * 输出描述：
 * 输出字符串中最长的数字字符串和它的长度，中间用逗号间隔。
 * 如果有相同长度的串，则要一块儿输出（中间不要输出空格）。
 */
public class FindLongestNumberString {

    private static void getSolution(String str) {
        int n = str.length();
        //存储原字符串中当前位置及之前的数字字符串的长度
        int[] dp = new int[n];
        dp[0] = str.charAt(0) >= '0' && str.charAt(0) <= '9' ? 1 : 0;
        int maxLen = str.charAt(0) >= '0' && str.charAt(0) <= '9' ? 1 : 0;
        for (int i = 1; i < n; i++) {
            if (str.charAt(i) >= '0' && str.charAt(i) <= '9') {
                dp[i] = dp[i-1] + 1;
            }
            maxLen = Math.max(maxLen, dp[i]);
        }

        for (int i = 0; i < dp.length; i++) {
            if (dp[i] == maxLen) {
                System.out.print(str.substring(i-maxLen+1,i+1));
            }
        }
        System.out.print(","+maxLen);
        System.out.println();
    }

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        while (sc.hasNext()) {
            getSolution(sc.next());
        }
    }
}
