package org.example.algorithm;


/**
 * 给定一个长度为n的整数数组height。
 * 有n条垂线，第i条线的两个端点是(i, 0)和(i, height[i]) 。
 * 找出其中的两条线，使得它们与x轴共同构成的容器可以容纳最多的水。
 * 返回容器可以储存的最大水量。
 */
public class MaxArea {

    public static int maxArea(int[] height) {
        int left = 0;
        int right = height.length - 1;
        int s = 0;
        while (left < right) {
            int width = right - left;
            int high = Math.min(height[left], height[right]);
            s = Math.max(s, width * high);
            if (height[left] < height[right]) {
                left++;
            } else {
                right--;
            }
        }
        return s;
    }


}
