package org.example.algorithm;

import java.util.LinkedList;
import java.util.Queue;
import java.util.Scanner;
import java.util.Stack;

/**
 * 定义一个二维数组 N*M ，如 5 × 5 数组下所示：
 * int maze[5][5] = {
 * 0, 1, 0, 0, 0,
 * 0, 1, 1, 1, 0,
 * 0, 0, 0, 0, 0,
 * 0, 1, 1, 1, 0,
 * 0, 0, 0, 1, 0,
 * };
 * 它表示一个迷宫，其中的1表示墙壁，0表示可以走的路，只能横着走或竖着走，不能斜着走，要求编程序找出从左上角到右下角的路线。
 * 入口点为[0,0],既第一格是可以走的路。
 * 数据范围：2≤n,m≤10,输入的内容只包含0≤val≤1
 * 输入描述：
 * 输入两个整数，分别表示二维数组的行数，列数。
 * 再输入相应的数组，其中的1表示墙壁，0表示可以走的路。
 * 数据保证有唯一解,不考虑有多解的情况，即迷宫只有一条通道。
 * 输出描述：左上角到右下角的最短路径。
 */
public class MazeSolver {

    private static final int[][] dirs = {{0, 1}, {0, -1}, {1, 0}, {-1, 0}};

    static class Point {
        private int x;
        private int y;
        private Point parent;

        public Point() {
        }

        public Point(int x, int y, Point parent) {
            this.x = x;
            this.y = y;
            this.parent = parent;
        }
    }

    private static void bfsFindPath(int[][] maze) {
        int n = maze.length;
        int m = maze[0].length;
        boolean[][] visited = new boolean[n][m];
        Queue<Point> queue = new LinkedList<>();
        queue.add(new Point());
        visited[0][0] = true;
        boolean found = false;
        Point end = null;
        while (!queue.isEmpty()) {
            Point cur = queue.poll();
            if (cur.x == n - 1 && cur.y == m - 1) {
                found = true;
                end = cur;
                break;
            }

            for (int[] dir : dirs) {
                int newX = cur.x + dir[0];
                int newY = cur.y + dir[1];
                if (newX >= 0 && newX < n && newY >= 0 && newY < m
                        && !visited[newX][newY] && maze[newX][newY] == 0) {
                    visited[newX][newY] = true;
                    queue.add(new Point(newX, newY, cur));
                }
            }
        }

        if (found) {
            Stack<Point> path = new Stack<>();
            while (end != null) {
                path.push(end);
                end = end.parent;
            }

            while (!path.isEmpty()) {
                Point point = path.pop();
                System.out.println(String.format("(%s,%s)", point.x, point.y));
            }
        } else {
            System.out.println("No path found.");
        }
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int n = scanner.nextInt();
        int m = scanner.nextInt();
        int[][] maze = new int[n][m];
        for (int i = 0; i < n; i++) {
            for (int j = 0; j < m; j++) {
                maze[i][j] = scanner.nextInt();
            }
        }

        bfsFindPath(maze);
    }

}
