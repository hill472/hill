package org.example.algorithm;


import java.util.Scanner;

/**
 题目描述
 我叫王大锤，是一名特工。我刚刚接到任务：在字节跳动大街进行埋伏，抓捕恐怖分子孔连顺。和我一起行动的还有另外两名特工，我提议
 1. 我们在字节跳动大街的N个建筑中选定3个埋伏地点。
 2. 为了相互照应，我们决定相距最远的两名特工间的距离不超过D。
 请听题：给定N（可选作为埋伏点的建筑物数）、D（相距最远的两名特工间的距离的最大值）以及可选建筑的坐标，计算在这次行动中，大锤的小队有多少种埋伏选择。
 注意：
 1. 两个特工不能埋伏在同一地点
 2. 三个特工是等价的：即同样的位置组合(A, B, C) 只算一种埋伏方法，不能因“特工之间互换位置”而重复使用
 输入描述：
 第一行包含空格分隔的两个数字 N和D(1≤N≤1000000; 1≤D≤1000000)
 第二行包含N个建筑物的的位置，每个位置用一个整数（取值区间为[0, 1000000]）表示，从小到大排列（将字节跳动大街看做一条数轴）
 输出描述：
 一个数字，表示不同埋伏方案的数量。结果可能溢出，请对 99997867 取模
 */
public class CountAmbushOptions {


    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        // 输入 N 和 D
        int N = scanner.nextInt();
        long D = scanner.nextLong();
        long[] buildings = new long[N];

        // 输入各个建筑物的坐标
        for (int i = 0; i < N; i++) {
            buildings[i] = scanner.nextLong();
        }

        // 计算并输出埋伏选择的数量
        long count = getSolution(buildings, D);
        System.out.println(count);

        scanner.close();
    }

    public static long getSolution(long[] buildings, long D) {
        // 初始化dp数组
        long[] dp = new long[buildings.length];

        // 初始化计数和第一个窗口（如果适用）
        if (buildings.length >= 3 && buildings[2] - buildings[0] <= D) {
            dp[2] = 1;
        }

        // 遍历建筑物数组
        for (int i = 3, j = 0; i < buildings.length; i++) {
            // 跳过不满足条件的j
            while (j <= i - 2 && buildings[i] - buildings[j] > D) {
                j++;
            }
            // 计算组合数并存储到dp[i]
            if (buildings[i] - buildings[j] <= D) {
                dp[i] = (long)(i - j) * (i - j - 1) / 2;
            }

            // 循环结束后，i 自增
        }

        // 计算总和并对结果取模
        long sum = 0;
        for (long count : dp) {
            sum += count;
        }
        return sum;
    }

}
