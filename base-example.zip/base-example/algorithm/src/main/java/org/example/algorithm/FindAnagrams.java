package org.example.algorithm;

import java.util.*;

/**
 *给定两个字符串s和p，找到s中所有p的异位词的子串，返回这些子串的起始索引。不考虑答案输出的顺序。
 */
public class FindAnagrams {

    public static List<Integer> findAnagrams(String s, String p) {
        List<Integer> answer = new ArrayList<>();
        if (s == null || p == null || s.length() < p.length()) {
            return answer;
        }

        Map<Character, Integer> window = new HashMap<>(); // 窗口哈希表
        Map<Character, Integer> target = new HashMap<>(); // 目标哈希表

        // 初始化目标哈希表
        for (char c : p.toCharArray()) {
            target.put(c, target.getOrDefault(c, 0) + 1);
        }

        // 初始化窗口哈希表
        for (int i = 0; i < p.length(); ++i) {
            window.put(s.charAt(i), window.getOrDefault(s.charAt(i), 0) + 1);
        }

        int w_start = 0, w_end = p.length() - 1; // 窗口边界

        // 滑动窗口搜索
        while (true) {
            // 哈希表相等则为异位词关系
            if (window.equals(target)) {
                answer.add(w_start);
            }

            // 到达字符串末尾，退出循环
            if (w_end == s.length()-1) break;

            // 移动窗口
            window.put(s.charAt(w_start), window.get(s.charAt(w_start)) - 1);
            if (window.get(s.charAt(w_start)) == 0) {
                window.remove(s.charAt(w_start)); // 移除无效的 key
            }
            w_start++;
            w_end++;
            window.put(s.charAt(w_end), window.getOrDefault(s.charAt(w_end), 0) + 1);
        }

        return answer;
    }

    public static void main(String[] args) {
        String s = "ababa";
        String p = "bbaa";
//        System.out.println(findAnagrams(s, p));
        Map<Character, Integer> window = new HashMap<>(); // 窗口哈希表
        Map<Character, Integer> target = new HashMap<>(); // 目标哈希表

        // 初始化目标哈希表
        for (char c : p.toCharArray()) {
            target.put(c, target.getOrDefault(c, 0) + 1);
        }
        System.out.println(target);
        List<String> strings = new ArrayList<>(Arrays.asList("a"));

        strings.add("b");
    }

}
