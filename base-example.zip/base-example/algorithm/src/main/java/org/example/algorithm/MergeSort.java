package org.example.algorithm;

/**
 * “归并”的含义是将两个或两个以上的有序序列组合成一个新的有序表。
 * 假设初始序列含有n个记录，则可以看成是n个有序的子序列
 * 每个子序列的长度为1，然后两两归并，得到⌈n/2⌉（⌈x⌉表示不小于x的最小整数）个长度为2(或者是1)的有序子序列
 * 再两两归并。如此重复，直到得到一个长度为n的有序序列为止。这种排序方法称为2-路归并排序。
 * 时间复杂度：O(nlogn)
 * 空间复杂度：O(n)
 */
public class MergeSort {

    public static void mergeSort(int[] arr, int L, int R) {
        if (arr == null || arr.length < 2)
            return;

        if (L == R)
            return;

        int M = L + (R - L) / 2;
        mergeSort(arr, L, M);
        mergeSort(arr, M + 1, R);
        merge(arr, L, M, R);
    }

    private static void merge(int[] arr, int L, int M, int R) {
        int p1 = L;
        int p2 = M + 1;
        int[] help = new int[R - L + 1];
        int i = 0;
        while (p1 <= M && p2 <= R) {
            if (arr[p1] < arr[p2]) {
                help[i] = arr[p1];
                p1++;
            } else {
                help[i] = arr[p2];
                p2++;
            }
            i++;
        }
        while (p1 <= M) {
            help[i] = arr[p1];
            i++;
            p1++;
        }
        while (p2 <= R) {
            help[i] = arr[p2];
            i++;
            p2++;
        }
        for (i = 0; i < help.length; i++)
            arr[L + i] = help[i];
    }

    public static void main(String[] args) {
        int[] a = {2, 5, 3, 1, 4, 3, 1, 4, 54, 6};
        mergeSort(a, 0, 9);
        for (int x : a)
            System.out.print(x + " ");
    }
}