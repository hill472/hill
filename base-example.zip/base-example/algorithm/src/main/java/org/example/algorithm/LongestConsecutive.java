package org.example.algorithm;

import java.util.HashSet;
import java.util.Set;

/**
 * 给定一个未排序的整数数组nums
 * 找出数字连续的最长序列（不要求序列元素在原数组中连续）的长度
 */
public class LongestConsecutive {


    public static int longestConsecutive(int[] nums) {
        Set<Integer> num_set = new HashSet<>();
        for (int num : nums) {
            num_set.add(num);
        }

        int longestLength = 0;
        for (int num : num_set) {
            if (num_set.contains(num - 1)) continue;

            int curNum = num;
            int curLen = 1;
            while (num_set.contains(curNum + 1)) {
                curNum++;
                curLen++;
            }
            longestLength = Math.max(longestLength, curLen);
        }

        return longestLength;
    }

    public static void main(String[] args) {

    }

}
