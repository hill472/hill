package org.example.algorithm;

import java.util.Scanner;

public class TaxiFareCalculator {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        // 输入表面读数
        int displayedNumber = scanner.nextInt();
        scanner.close();

        // 调用函数计算实际费用
        int actualFare = calculateActualFare(displayedNumber);
        System.out.println(actualFare);
    }


    private static int calculateActualFare(int number) {
        int cost = number; // 实际费用

        // 模拟计费表，跳过包含数字4的数字
        while (number > 0) {
            if (containsDigitFour(number)) { // 判断当前位是否是4
                cost--;
            }
            number--; // 去掉最后一位
        }

        return cost;
    }

    /**
     * 判断一个数字是否包含数字4
     *
     * @param number 数字
     * @return 是否包含数字4
     */
    private static boolean containsDigitFour(int number) {
        while (number > 0) {
            if (number % 10 == 4) { // 判断当前位是否是4
                return true;
            }
            number /= 10; // 去掉最后一位
        }
        return false;
    }
}

