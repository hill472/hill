package org.example.algorithm;

import com.google.common.collect.Lists;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;
import java.util.Queue;

/**
 * 爬n楼梯
 * 每次走一步或者两步
 * 输出所有走法的组合
 */
public class ClimbStairsCombinations {

    private static final List<List<Integer>> result = Lists.newArrayList();

    private static final int[] steps = {1, 2};

    static class State {
        int step;  // 当前所在的楼梯阶数
        List<Integer> path;  // 走到当前阶数的走法路径

        State(int step, List<Integer> path) {
            this.step = step;
            this.path = path;
        }
    }

    //递归版
    private static void climbStairsHelper(int n, List<Integer> path) {
        if (n == 0) {
            result.add(Lists.newArrayList(path));
            return;
        }

        for (int step : steps) {
            if (n - step >= 0) {
                List<Integer> tmp = new ArrayList<>(path);
                tmp.add(step);
                climbStairsHelper(n - step, tmp);
            }
        }
    }

    private static List<List<Integer>> bfsClimbStairs(int n) {
        List<List<Integer>> res = Lists.newArrayList();
        Queue<State> queue = new LinkedList<>();
        State state = new State(n, new ArrayList<>());
        queue.offer(state);
        while (!queue.isEmpty()) {
            State curState = queue.poll();
            if (curState.step == 0) {
                res.add(new ArrayList<>(curState.path));
                continue;
            }

            for (int step : steps) {
                if (curState.step - step >= 0) {
                    List<Integer> path = new ArrayList<>(curState.path);
                    path.add(step);
                    queue.offer(new State(curState.step - step , path));
                }
            }
        }
        return res;
    }

    public static void main(String[] args) {
        climbStairsHelper(4, Lists.newArrayList());
        for (List<Integer> path : result) {
            System.out.println(path);
        }

        System.out.println(bfsClimbStairs(4));
    }
}
