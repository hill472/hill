package org.example.algorithm;

/**
 * 给定一个大小为 n 的数组 nums ，返回其中的多数元素。
 * 多数元素是指在数组中出现次数 大于 ⌊ n/2 ⌋ 的元素。
 * 你可以假设数组是非空的，并且给定的数组总是存在多数元素。
 */
public class MajorNumber {

    public static int getMajority(int[] nums) {
        int cnt = 1;
        int candidate = nums[0];
        for (int i = 1; i < nums.length; i++) {
            if (candidate == nums[i]) {
                cnt++;
            } else if (cnt == 0) {
                candidate = nums[i];
                cnt = 1;
            } else {
                cnt++;
            }
        }
        return candidate;
    }

    public static void main(String[] args) {
        int[] nums = {2,2,1,1,1,2,2};
        System.out.println(getMajority(nums));
    }

}
