package org.example.algorithm;

/**
 * 堆排序的步骤：
 * 首先建立一个大顶堆，堆的大小为heapsize，然后将堆顶和最后一个元素交换位置，
 * 然后在0~heapsize-1范围调整堆顶的位置，使其再成为一个heapsize-1的大顶堆，
 * 重复上面步骤，直到heapsize变为0，此时就排好序了
 * 时间复杂度：O(nlogn)
 * 空间复杂度：O(1)
 */
public class HeapSort {

    public static void swap(int[] arr, int i, int j) {
        int tmp = arr[i];
        arr[i] = arr[j];
        arr[j] = tmp;
    }

    //构建大顶堆
    public static void HeapInsert(int[] arr, int i) {
        while (arr[i] > arr[(i - 1) / 2]) {
            swap(arr, i, (i - 1) / 2);
            i = (i - 1) / 2;
        }
    }

    public static void Heapify(int[] arr, int i, int heapsize) {
        int left = (i << 1) + 1;
        while (left <= heapsize) {
            int right = left + 1;
            int maxIndex = right <= heapsize && arr[right] > arr[left] ? right : left;

            if (arr[maxIndex] <= arr[i])
                break;

            swap(arr, i, maxIndex);
            i = maxIndex;
            left = (i << 1) + 1;
        }
    }

    public static void HeapSort(int[] arr) {
        if (arr == null || arr.length < 2)
            return;

        //构建大顶堆
        for (int i = 0; i < arr.length; i++)
            HeapInsert(arr, i);

        //将堆顶与最后一个数交换，调整除了最后一个数的堆，使其再成为大顶堆，
        //再将堆顶与最后一个元素交换......
        int heapsize = arr.length-1;
        while(heapsize >= 0){
            swap(arr, 0, heapsize);
            heapsize--;
            Heapify(arr, 0, heapsize);
        }
    }

    public static void main(String[] args) {
        int[] a = {2, 1,2,1, 2};
        HeapSort(a);
        for (int x : a)
            System.out.print(x + " ");
    }
}
