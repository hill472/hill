package org.example.algorithm;

/**
 * 给定两个以字符串形式表示的非负整数num1和num2，返回num1和num2的乘积，它们的乘积也表示为字符串形式。
 * 注意：不能使用任何内置的BigInteger库或直接将输入转换为整数。
 */
public class StringMultiply {

    public static String getSolution(String num1, String num2) {
        int n = num1.length();
        int m = num2.length();
        int[] A = new int[n];
        int[] B = new int[m];
        for (int i = n - 1; i >= 0; i--) {
            A[n - 1 - i] = num1.charAt(i) - '0'; //反向存贮
        }
        for (int i = m - 1; i >= 0; i--) {
            B[m - 1 - i] = num2.charAt(i) - '0';
        }

        int[] C = new int[n + m];
        for (int i = 0; i < n; i++) {
            for (int j = 0; j < m; j++) {
                C[i + j] += A[i] * B[j];
            }
        }

        /*
            index: 5   4   3   2   1   0
                 A[i]:         1   2   3
               x B[j]:         4   5   6
        ---------------------------------
                               6   12  18
                           5  10   15
                       4   8  12
        ---------------------------------
            c[i + j]:  4  13  28   27  18
        （满10进位）    1   3   2    1
        ---------------------------------
                       5   6   0    8   8
         */
        int t = 0; //存贮进位
        for (int i = 0; i < C.length; i++) {
            t += C[i];
            C[i] = t % 10;
            t /= 10;
        }
        int k = C.length - 1;
        while (k > 0 && C[k] == 0) k--;   //去除前导0
        StringBuilder sb = new StringBuilder();
        while (k >= 0) sb.append((char) (C[k--] + '0')); //反转
        return sb.toString();
    }

    public static void main(String[] args) {
        String num1 = "123";
        String num2 = "456";
        System.out.println(getSolution(num1, num2));
    }
}
