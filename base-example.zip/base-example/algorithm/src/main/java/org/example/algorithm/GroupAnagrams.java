package org.example.algorithm;

import java.util.*;

/**
 * 给你一个字符串数组，请你将 字母异位词 组合在一起。可以按任意顺序返回结果列表。
 * 字母异位词 是由重新排列源单词的所有字母得到的一个新单词。
 */
public class GroupAnagrams {
    private static Map<Character, Integer> getAnagramsMap(String p) {
        Map<Character, Integer> target = new HashMap<>();
        for (char c : p.toCharArray()) {
            target.put(c, target.getOrDefault(c, 0) + 1);
        }
        return target;
    }

    public static List<List<String>> groupAnagrams(String[] strs) {
        List<List<String>> answer = new ArrayList<>();
        if (strs.length < 1) {
            return answer;
        }

        Map<Map<Character, Integer>, List<String>> help = new HashMap<>();
        for (int i = 0; i < strs.length; i++) {
            Map<Character, Integer> tk = getAnagramsMap(strs[i]);
            if (help.containsKey(tk)) {
                help.get(tk).add(strs[i]);
            } else {
                help.put(tk, new ArrayList<>(Arrays.asList(strs[i])));
            }
        }

        return new ArrayList<>(help.values());
    }

    public static void main(String[] args) {
        String[] strs = new String[]{""};
        System.out.println(groupAnagrams(strs));
    }

}
