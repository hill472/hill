package org.example.algorithm;

import java.util.Stack;

/**
 * 输入一个表达式（用字符串表示），求这个表达式的值。
 * 保证字符串中的有效字符包括['0'-'9'],'+','-', '*','/' ,'('， ')','[', ']','{' ,'}'。
 * 且表达式一定合法。
 * 数据范围：表达式计算结果和过程中满足∣val∣≤1000，字符串长度满足1≤n≤1000
 * 输入描述：输入一个算术表达式
 * 输出描述：得到计算结果
 * 主要思路如下：
 * compute函数是递归函数，用来处理整个表达式及其任何嵌套子表达式。
 * 当函数遇到一个开括号 ({、[、() 时，就递归调用自身，处理括号内的表达式。
 * 函数通过一个整数数组（模拟栈）来计算表达式中基本的加减乘除运算。
 * 加法或减法运算时，将数字压入栈；乘法或除法运算时，将当前数字与栈顶元素计算后的结果更新回栈顶。
 * 每个数字或子表达式的结果存储在栈中，直到处理完整个表达式。
 * 最后，所有栈中的元素被相加以求得最终结果。
 * 重要的是，当 compute 函数遇到闭括号，就会停止处理当前子表达式并返回计算结果。
 * 由于 pos 是静态变量，递归调用不会互相干扰其值。这同样的逻辑可以适用于任意深度的嵌套表达式。
 */
public class ExpressionEvaluator {

    private static int pos = 0; // 定义一个静态变量pos，它将在整个表达式中跟踪当前的位置

    private static int compute(String data) { // 定义一个递归方法compute，它将计算一个字符串表达式
        // 定义一个栈，用于存储中间结果
        Stack<Integer> nums = new Stack<>();
        int num = 0; // 当前正在解析的数字
        char flag = '+'; // 当前考虑的运算符，默认为'+'
        int len = data.length(); // 表达式的总长度

        while (pos < len) { // 当位置指针没有超过字符串长度时，继续循环
            if (data.charAt(pos) == '{' || data.charAt(pos) == '[' || data.charAt(pos) == '(') { // 如果当前字符是开括号
                pos++; // 移动位置指针到下一个字符
                num = compute(data); // 递归调用compute方法，处理括号内的表达式
            }

            while (pos < len && Character.isDigit(data.charAt(pos))) { // 如果当前字符是数字
                num = num * 10 + (data.charAt(pos) - '0'); // 累积数字值（处理多位数）
                pos++; // 移动位置指针到下一个字符
            }

            // 根据当前运算符标志flag来处理栈顶部元素与当前数字num的运算
            switch (flag) {
                case '+':
                    nums.push(num); // 加法：将数字压入栈顶
                    break;
                case '-':
                    nums.push(-num); // 减法：将数字取反后压入栈顶
                    break;
                case '*':
                    nums.push(nums.pop() * num); // 乘法：与栈顶数字相乘
                    break;
                case '/':
                    nums.push(nums.pop() / num); // 除法：与栈顶数字相除
                    break;
            }

            // 更新flag为当前位置的运算符或括号，并重置num以处理下一个数字
            if (pos < len) {
                flag = data.charAt(pos);
            }
            num = 0;

            // 如果当前字符是闭括号，结束循环
            if (pos < len && (data.charAt(pos) == '}' || data.charAt(pos) == ']' || data.charAt(pos) == ')')) {
                pos++;
                break;
            }
            pos++;
        }

        // 结束主循环后，将栈中所有数字相加以求得表达式的值
        int rc = 0; // 初始化结果值
        while (!nums.isEmpty()) {
            rc += nums.pop(); // 将栈中的数字累加
        }
        return rc; // 返回计算结果
    }

    public static void main(String[] args) {
        String expressionStr = "3+2*{1+2*[-4/(8-6)+7]}";
        System.out.println(compute(expressionStr));
    }


}
