package org.example.algorithm;

import java.util.*;

public class BinaryTree {

    // 定义二叉树节点
    static class TreeNode {
        private final int val;
        private TreeNode left;
        private TreeNode right;

        TreeNode(int x) {
            val = x;
        }
    }

    //前序遍历, 根节点，左节点，右节点
    public static void preOrderRecur(TreeNode root) {
        System.out.println("前序遍历：");
        if (root == null)
            return;

        Stack<TreeNode> stack = new Stack<>();
        stack.push(root);
        while (!stack.isEmpty()) {
            TreeNode head = stack.pop();
            System.out.print(head.val + " ");
            if (head.right != null) {
                stack.push(head.right);
            }

            if (head.left != null) {
                stack.push(head.left);
            }
        }
        System.out.println();
    }

    //中序遍历, 左节点，根节点，右节点
    public static void inOrderRecur(TreeNode root) {
        System.out.println("中序遍历：");
        if (root == null)
            return;

        Stack<TreeNode> stack = new Stack<>();
        while (!stack.isEmpty() || root != null) {
            if (root != null) {
                stack.push(root);
                root = root.left;
            } else {
                root = stack.pop();
                System.out.print(root.val + " ");
                root = root.right;
            }
        }
        System.out.println();
    }

    //后序遍历, 左节点，右节点，根节点
    public static void postOrderRecur(TreeNode root) {
        System.out.println("后序遍历：");
        if (root == null)
            return;

        Stack<TreeNode> stack = new Stack<>();
        Stack<TreeNode> output = new Stack<>(); // 用于按后序遍历的顺序保存节点
        stack.push(root);

        while (!stack.isEmpty()) {
            TreeNode node = stack.pop();
            output.push(node);

            // 为了让左子节点在右子节点之后处理，我们首先将左子节点入栈，然后才是右子节点
            if (node.left != null) {
                stack.push(node.left);
            }
            if (node.right != null) {
                stack.push(node.right);
            }
        }

        // 输出后序遍历的结果
        while (!output.isEmpty()) {
            TreeNode node = output.pop();
            System.out.print(node.val + " ");
        }

        System.out.println();
    }

    //层序遍历
    public static void levelOrderRecur(TreeNode root) {
        System.out.println("层序遍历：");
        if (root == null)
            return;

        Queue<TreeNode> queue = new LinkedList<>();
        queue.add(root);
        while (!queue.isEmpty()) {
            int nodeSize = queue.size();
            for (int i = 0; i < nodeSize; i++) {
                TreeNode head = queue.poll();
                System.out.print(head.val + " ");
                if (head.left != null) {
                    queue.add(head.left);
                }

                if (head.right != null) {
                    queue.add(head.right);
                }
            }
        }
        System.out.println();
    }

    public static void main(String[] args) {
        // 创建一个简单的二叉树作为示例
        //        1
        //       / \
        //      2   3
        //     / \   \
        //    4   5   6
        TreeNode root = new TreeNode(1);
        root.left = new TreeNode(2);
        root.right = new TreeNode(3);
        root.left.left = new TreeNode(4);
        root.left.right = new TreeNode(5);
        root.right.right = new TreeNode(6);
        //前序遍历
        preOrderRecur(root);
        //中序遍历
        inOrderRecur(root);
        //后序遍历
        postOrderRecur(root);
        //层序遍历
        levelOrderRecur(root);
    }
}