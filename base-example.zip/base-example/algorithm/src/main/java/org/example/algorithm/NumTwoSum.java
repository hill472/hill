package org.example.algorithm;

import com.google.common.collect.Lists;

import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/**
 * 给你一个整数数组nums，判断是否存在三元组 [nums[i], nums[j], nums[k]]
 * 满足 i != j、i != k 且 j != k ，同时还满足 nums[i] + nums[j] + nums[k] == 0。
 * 请你返回所有和为 0 且不重复的三元组。
 */
public class NumTwoSum {

    public static Set<List<Integer>> twoSum(int[] nums, int sum) {
        Set<List<Integer>> res = new HashSet<>();
        if (nums.length < 2)
            return res;

        Arrays.sort(nums);
        int n = nums.length;
        int p1 = 0;
        int p2 = n - 1;
        while (p1 < p2) {
            int target = nums[p1] + nums[p2];
            if (target == sum) {
                res.add(Lists.newArrayList(nums[p1], nums[p2]));
                p1++;
                p2--;
            } else if (target < sum) {
                p1++;
            } else {
                p2--;
            }
        }

        return res;
    }
    
    public static void main(String[] args) {
        int[] nums = {-1, 0, 1, 2, -1, -2};
        Set<List<Integer>> res = twoSum(nums, 0);
        System.out.println(res);
    }

}
