package org.example.algorithm;

import java.util.PriorityQueue;

public class FindTopN {

    public static void findTopN(int[] nums, int n) {
        PriorityQueue<Integer> minHeap = new PriorityQueue<>();
        for (int num : nums) {
            if (minHeap.size() < n) {
                minHeap.offer(num);
            } else if (num > minHeap.peek()) {
                minHeap.poll();
                minHeap.offer(num);
            }
        }

        while (!minHeap.isEmpty()) {
            System.out.println(minHeap.poll());
        }
    }

    public static void main(String[] args) {
        int[] nums = {3, 2, 1, 5, 6, 4};
        findTopN(nums, 2);
    }

}