package org.example.algorithm;

import com.google.common.collect.Lists;

import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class NumFourSum {

    //sum = arr[a] + arr[b] + arr[c] + arr
    //2,2,2,2,2
    //i,j,p1, p2
    public static Set<List<Integer>> fourSum(int[] arr, long sum) {
        Set<List<Integer>> res = new HashSet<>();
        if (arr.length < 4)
            return res;

        Arrays.sort(arr);
        int n = arr.length;
        for (int i = 0; i < n - 3; i++) {
            if ((long) arr[i] + arr[i + 1] + arr[i + 2] + arr[i + 3] > sum) {
                break;
            }

            if ((long) arr[i] + arr[n - 3] + arr[n - 2] + arr[n - 1] < sum) {
                continue;
            }

            for (int j = i + 1; j < n - 2; j++) {
                if ((long) arr[i] + arr[j] + arr[j + 1] + arr[j + 2] > sum) {
                    break;
                }

                if ((long) arr[i] + arr[j] + arr[n - 2] + arr[n - 1] < sum) {
                    continue;
                }

                int p1 = j + 1;
                int p2 = n - 1;

                while (p1 < p2) {
                    long target = arr[i] + arr[j] + arr[p1] + arr[p2];
                    if (target == sum) {
                        res.add(Lists.newArrayList(arr[i], arr[j], arr[p1], arr[p2]));
                        p1++;
                        p2--;
                    } else if (target < sum) {
                        p1++;
                    } else {
                        p2--;
                    }
                }

            }
        }
        return res;
    }

    public static void main(String[] args) {
        int[] arr1 = {0, 0, 0, 1000000000, 1000000000, 1000000000, 1000000000};
        int sum1 = 1000000000;
//        int[] arr2 = {2, 2, 2, 2, 2};
//        int sum2 = 8;
        System.out.println(fourSum(arr1, sum1));
//        System.out.println(fourSum(arr2, sum2));
    }

}
