package org.example.algorithm;

import com.google.common.collect.Lists;

import java.util.Arrays;
import java.util.Comparator;
import java.util.List;

public class SortStringsByNumber {

    private static String sortString(String input) {
        // 临时数组，用于存储字母并进行排序
        List<Character> chars = Lists.newArrayList();
        char[] charArray = input.toCharArray();
        for (char c : charArray) {
            if (Character.isLetter(c)) {
                chars.add(c);
            }
        }
        chars.sort((c1, c2) -> c1.toString().compareToIgnoreCase(c2.toString()));
        char[] tmp = new char[charArray.length];
        int j = 0;
        for (int i = 0; i < charArray.length; i++) {
            if (Character.isLetter(charArray[i])) {
                tmp[i] = chars.get(j++);
            } else {
                tmp[i] = charArray[i];
            }
        }

        return String.valueOf(tmp);
    }

    public static void main(String[] args) {
        String[] testInputs = {"Type", "BabA", "By?e"};
        for (String testInput : testInputs) {
            System.out.println(sortString(testInput));
        }
    }

}
