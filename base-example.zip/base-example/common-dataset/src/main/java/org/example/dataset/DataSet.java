package org.example.dataset;

import com.esotericsoftware.kryo.Kryo;
import org.example.model.Tuple2;
import org.example.util.ComUtil;
import org.example.util.ConvertUtil;
import org.example.util.CsvUtil;
//import org.example.util.SqlUtil;
import org.apache.commons.lang3.StringUtils;
import javax.validation.constraints.NotNull;
import java.io.Serializable;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.util.*;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.function.Predicate;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import static java.util.stream.Collectors.toList;

/**
 * Created with IntelliJ IDEA.
 *
 * @Author: HillHuang
 * @Date: 2021/10/15/11:34
 * @Description:
 */
//@Component
public class DataSet implements Serializable {

    private List<Row> data;
    private StructType schema;
    private Integer row_number;
    private final static ThreadLocal<Kryo> Kryo = ThreadLocal.withInitial(() -> {
        Kryo kryo = new Kryo();
        kryo.setRegistrationRequired(false);
        return kryo;
    });

//    @Resource
//    SqlSessionTemplate sqlSessionTemplate;
//
//    private static SqlSessionTemplate sqlSession;
//
//    @PostConstruct
//    public void init() {
//        sqlSession = sqlSessionTemplate;
//    }

    private DataSet() {
        this.data = new ArrayList<>();
        this.schema = StructType.create();
    }

    private DataSet(StructType schema, List<Row> data) {
        this.data = data;
        this.schema = schema;
    }

    public static DataSet create() {
        return new DataSet();
    }

    public static DataSet createDataSet(@NotNull StructType schema, @NotNull List<Row> data) {
        for (Row row : data) {
            if (!schema.equals(row.getSchema())) {
                throw new IllegalArgumentException("the schema should be equal to the schema of Row in data.");
            }
        }
        return new DataSet(schema, data);
    }

    //初始一个dataSet，指定列名及其数据类型
    public static DataSet createDataSet(@NotNull String[] columnNames, @NotNull Class<?>... columnTypes) {
        int size = columnNames.length;
        int length = columnTypes.length;
        if (size != length) {
            throw new IllegalArgumentException("the length of columnNames should be equal to that of columnTypes");
        }
        DataSet dataset = DataSet.create();
        StructField[] structFields = new StructField[size];
        for (int i = 0; i < size; i++) {
            structFields[i] = StructField.createStructField(columnNames[i], columnTypes[i]);
        }
        dataset.setSchema(StructType.createStructType(structFields));
        return dataset;
    }

    //从一列数据构建
    public static <T> DataSet createFromData(String columnName, Class<?> columnType, List<T> data) {
        DataSet dataSet = createDataSet(new String[]{columnName}, columnType);
        StructType schema = dataSet.schema;
        for (T obj : data) {
            dataSet.data.add(Row.createRow(schema, obj));
        }
        return dataSet;
    }

    //从数据集构建
    public static DataSet createFromData(String[] columnNames, Class<?>[] columnTypes, List<List<Object>> datas) {
        DataSet dataSet = createDataSet(columnNames, columnTypes);
        StructType schema = dataSet.schema;
        for (List<Object> data : datas) {
            dataSet.data.add(Row.createRow(schema, data));
        }
        return dataSet;
    }

    //从map数据集构建，所有列的类型均为Object
    public static DataSet createFromData(List<Map<String, Object>> mapData) {
        List<List<Object>> dataList = mapData.stream()
                .map(map_data -> new ArrayList<>(map_data.values()))
                .collect(toList());
        String[] colNames = mapData.get(0).keySet().toArray(new String[0]);
        int length = colNames.length;
        Class<?>[] columnTypes = new Class[length];
        for (int i = 0; i < length; i++) {
            columnTypes[i] = Object.class;
        }
        return createFromData(colNames, columnTypes, dataList);
    }

    //从实体对象数据集构建
    public static <T> DataSet createFromData(List<T> objs, Class<T> objType) {
        try {
            DataSet dataSet = DataSet.create();
            Field[] fields = objType.getDeclaredFields();
            StructType schema = StructType.createStructType(objType);
            dataSet.setSchema(schema);
            for (T obj : objs) {
                List<Object> rowData = new ArrayList<>();
                for (Field field : fields) {
                    field.setAccessible(true);
                    Object val = field.get(obj);
                    rowData.add(val);
                }
                dataSet.data.add(Row.createRow(schema, rowData));
            }
            return dataSet;
        } catch (IllegalAccessException e) {
            e.printStackTrace();
        }
        return null;
    }

    public static <T> DataSet readCSV(Class<T> clz, String csvFilePath, Boolean header, char sep, Charset charset) {
        List<String[]> readCSV = CsvUtil.readCSV(csvFilePath, header, sep, charset);
        List<T> javaBeanList = ComUtil.createJavaBeanList(readCSV, clz);
        return createFromData(javaBeanList, clz);
    }

    public static <T> DataSet readCSV(Class<T> clz, String csvFilePath, Boolean header, char sep) {
        return readCSV(clz, csvFilePath, header, sep, StandardCharsets.UTF_8);
    }

    public static <T> DataSet readCSV(Class<T> clz, String csvFilePath, Boolean header) {
        return readCSV(clz, csvFilePath, header, ',');
    }

    public static <T> DataSet readCSV(Class<T> clz, String csvFilePath) {
        return readCSV(clz, csvFilePath, false);
    }

//    /**
//     * 从数据库访问接口构建dataSet
//     * @param nameSpace mapper.xml文件的包名全路径地址枚举类，如果不传默认是SqlUtil中的name_space
//     * @param sql_id 方法名
//     * @param query_param 查询参数
//     * @param objType 实体类
//     */
//
//    //指定nameSpace
//    public static <T> DataSet readSql(NameSpace nameSpace, String sql_id, Object query_param, Class<T> objType) {
//        List<T> objs = sqlSession.selectList(nameSpace.getPath() + sql_id, query_param);
//        return createFromData(objs, objType);
//    }
//
//    public static <T> DataSet readSql(NameSpace nameSpace, String sql_id, Class<T> objType) {
//        return readSql(nameSpace, sql_id, null, objType);
//    }
//
//    //mapper中的resultType为map，不指定实体类，返回一个map数据集
//    public static DataSet readSql(NameSpace nameSpace, String sql_id, Object query_param) {
//        List<Map<String, Object>> mapData = sqlSession.selectList(nameSpace.getPath() + sql_id, query_param);
//        return createFromData(mapData);
//    }
//
//    public static DataSet readSql(NameSpace nameSpace, String sql_id) {
//        return readSql(nameSpace, sql_id, (Object) null);
//    }
//
//    //不指定nameSpace
//    public static <T> DataSet readSql(String sql_id, Object query_param, Class<T> objType) {
//        List<T> objs = SqlUtil.selectList(sql_id, query_param);
//        return createFromData(objs, objType);
//    }
//
//    public static <T> DataSet readSql(String sql_id, Class<T> objType) {
//        return readSql(sql_id, null, objType);
//    }
//
//    public static DataSet readSql(String sql_id, Object query_param) {
//        List<Map<String, Object>> mapData = SqlUtil.selectList(sql_id, query_param);
//        return createFromData(mapData);
//    }
//
//    public static DataSet readSql(String sql_id) {
//        return readSql(sql_id, (Object) null);
//    }

    public List<Row> getData() {
        return data;
    }

    public void setData(List<Row> data) {
        this.data = data;
    }

    public StructType getSchema() {
        return schema;
    }

    public void setSchema() {
        this.schema = getData().get(0).getSchema();
    }

    public void setSchema(StructType structType) {
        this.schema = structType;
    }

    public Integer getRow_number() {
        return row_number;
    }

    public void setRow_number(Integer row_number) {
        this.row_number = row_number;
    }

    //获取所有列的列名list
    public List<String> getColNames() {
        return schema.getColNames();
    }

    //获取所有列的类型list
    public List<Class<?>> getColClasses() {
        return schema.getColClasses();
    }

    public <T> List<T> getColData(String col) {
        List<T> res = new ArrayList<>();
        this.select(col).forEach(row -> res.add(row.value(col)));
        return res;
    }

    public int size() {
        return data.size();
    }

    public int colSize() {
        return getColNames().size();
    }

    //获取指定列名的值类型
    public Class<?> getColType(String colName) {
        return getData().get(0).getColType(colName);
    }

    public Class<?> getColType(Integer i) {
        return getData().get(0).getColType(i);
    }

    //获取指定列名的值类型
    @SuppressWarnings("all")
    public <T> Class<T> colType(String colName) {
        return (Class<T>) getColType(colName);
    }

    @SuppressWarnings("all")
    public <T> Class<T> colType(Integer i) {
        return (Class<T>) getColType(i);
    }

    //获取指定列名的索引号
    public Integer getColIndex(String colName) {
        return getColNames().indexOf(colName);
    }

    //根据行号和列号取值，均从0开始
    @SuppressWarnings("all")
    public <T> T value(Integer row, Integer col) {
        String col_name = getColNames().get(col);
        return (T) getColData(col_name).get(row);
    }

    //python dataframe中的df.loc[条件]['col_name'],如果只有一条记录,则返回值;若有多条,则返回dataset
    @SuppressWarnings("all")
    public <T> T loc(Predicate<Row> rowPredicate, String colName) {
        DataSet filter = filter(rowPredicate);
        if (filter.size() == 1) {
            return filter.data.get(0).value(colName);
        }
        return (T) filter.select(colName);
    }

    public DataSet loc(Predicate<Row> rowPredicate) {
        return filter(rowPredicate);
    }

    //改变原来dataSet中某一列的值
    public <T, R> DataSet mapColumn(String colName, Function<T, R> mapper) {
        int i = getColIndex(colName);
        return map(row -> {
            List<Object> rowData = row.getData();
            T old_value = row.get(colName, row.colType(i));
            rowData.set(i, mapper.apply(old_value));
            return row;
        });
    }

    public DataSet map(Function<Row, Row> mapper) {
        DataSet copy = this.copy();
        List<Row> collect = copy.data.stream().map(mapper).collect(Collectors.toList());
        copy.setData(collect);
        copy.setSchema();
        return copy;
    }

    public DataSet flatMap(Function<Row, Stream<Row>> doRow) {
        DataSet copy = this.copy();
        List<Row> collect = copy.data.stream().flatMap(doRow).collect(toList());
        copy.setData(collect);
        copy.setSchema();
        return copy;
    }


    public <T, R> List<R> to_List(Function<T, List<R>> mapper, T t) {
        return mapper.apply(t);
    }

    public <R, S> S[] to_Arr(Function<R, S[]> mapper, R t) {
        return mapper.apply(t);
    }

    public <T, R> R process(Function<T, R> mapper, T t) {
        return mapper.apply(t);
    }

    /**
     * @param mapper    row.data：List<T> -> List<R>
     * @param arrMapper R -> S[]
     * @param <T>       未处理的Row中data元素的类型
     * @param <R>       data中的元素经处理后变为类型为R的元素
     * @param <S>       将元素R变成S[]
     * @return
     */
    @SuppressWarnings("all")
    public <T, R, S> DataSet flatMapByArr(Function<T, R> mapper, Function<R, S[]> arrMapper) {
        DataSet copy = this.copy();
        List<String> colNames = this.getColNames();
        List<Row> collect = copy.data.stream().flatMap(row -> {
            List<Row> res = new ArrayList<>();
            List<S> processedArr = row.getData().stream().flatMap(t -> {
                T o = (T) t;
                R process = process(mapper, o);     // T o -> R process
                S[] arr = to_Arr(arrMapper, process);   // R process -> S[]
                return Arrays.stream(arr);              // 由S[]构建Stream<S>
            }).collect(toList());
            List<Class<?>> classList = processedArr.stream().map((Function<S, ? extends Class<?>>) S::getClass).distinct().collect(toList());
            StructType schema = StructType.createStructType(colNames, classList);
            processedArr.forEach(s -> res.add(Row.createRow(schema, s)));
            return res.stream(); //Stream<Row>
        }).collect(toList());
        copy.setData(collect);
        copy.setSchema();
        return copy;
    }

    /**
     * @param mapper     row.data：List<T> -> List<R>
     * @param listMapper R -> List<S>
     * @param <T>        未处理的Row中data元素的类型
     * @param <R>        data中的元素经处理后变为类型为R的元素
     * @param <S>        将元素R变成List<S>
     * @return
     */
    @SuppressWarnings("all")
    public <T, R, S> DataSet flatMapByList(Function<T, R> mapper, Function<R, List<S>> listMapper) {
        DataSet copy = this.copy();
        List<String> colNames = this.getColNames();
        List<Row> collect = copy.data.stream().flatMap(row -> {
            List<Row> res = new ArrayList<>();
            List<S> processedList = row.getData().stream().flatMap(t -> {
                T o = (T) t;
                R process = process(mapper, o);            // T o -> R process
                List<S> list = to_List(listMapper, process);   // R process -> List<S>
                return list.stream();                          // 由List<S>构建Stream<S>
            }).collect(toList());
            List<Class<?>> classList = processedList.stream().map(s -> s.getClass()).distinct().collect(toList());
            StructType schema = StructType.createStructType(colNames, classList);
            processedList.forEach(s -> res.add(Row.createRow(schema, s)));
            return res.stream();
        }).collect(toList());
        copy.setData(collect);
        copy.setSchema();
        return copy;
    }

    public DataSet flatMapToString(String regex) {
        DataSet copy = this.copy();
        List<Row> collect = copy.data.stream().flatMap(row -> {
            StructType schema = row.getSchema();
            List<Row> res = new ArrayList<>();
            Stream<String> stringStream = row.getData().stream().flatMap(o -> Arrays.stream(((String) o).split(regex)));
            stringStream.forEach(s -> res.add(Row.createRow(schema, s)));
            return res.stream();
        }).collect(toList());
        copy.setData(collect);
        copy.setSchema();
        return copy;
    }

    //python dataframe中的merge(df1, df2, on="key")
    public DataSet merge(@NotNull DataSet other, @NotNull String key) {
        if (other.colSize() == 1) {
            List<Object> intersection = getColData(key);
            List<Object> right = other.getColData(key);
            intersection.retainAll(right);
            return filter(row -> intersection.contains(row.value(key)));
        }
        return join(other, key);
    }

    /**
     * 合并两个同类型的dataSet
     *
     * @param other      要合并的dataSet
     * @param isDistinct 合并后是否去重
     * @return
     */
    public DataSet rowMerge(@NotNull DataSet other, Boolean isDistinct) {
        if (!this.schema.equals(other.schema)) {
            throw new IllegalArgumentException("the schema of the two dataSets to be merged should be equal");
        }
        DataSet copy = this.copy();
        copy.data.addAll(other.data);
        List<Row> mergeData = copy.data.stream().distinct().collect(toList());
        if (isDistinct) {
            copy.setData(mergeData);
        }
        return copy;
    }

    public DataSet rowMerge(@NotNull DataSet other) {
        return rowMerge(other, true);
    }

    //两个dataset进行横向拼接, 没有公共列
    public DataSet columnMerge(@NotNull DataSet other) {
        if (this.schema.equals(other.schema)) {
            throw new IllegalArgumentException("the schema of the two dataSets to be merged should not be equal");
        }
        DataSet idx_other = other.addIncrementColumn();
        DataSet idx_this = this.addIncrementColumn();
        DataSet resDataSet = idx_this.leftJoin(idx_other, "idx");
        String[] selects = ComUtil.strArrNotContained(resDataSet.getColNames(), "idx");
        return resDataSet.select(selects);
    }

    public void forEach(Consumer<Row> rowConsumer) {
        data.forEach(rowConsumer);
    }

    public DataSet filter(Predicate<Row> rowPredicate) {
        DataSet copy = this.copy();
        List<Row> collect = copy.data.stream().filter(rowPredicate).collect(Collectors.toList());
        copy.setData(collect);
        return copy;
    }

    //选择某列数据去重
    public DataSet distinct(String colName) {
        DataSet select = select(colName);
        List<Row> distinctRows = select.data.stream().distinct().collect(toList());
        select.setData(distinctRows);
        return select;
    }

    //去除重复行
    public void distinct() {
        setData(data.stream().distinct().collect(toList()));
    }

    public void sort(Comparator<Row> cpt) {
        data.sort(cpt);
    }

    public void sort(@NotNull Sorter sorter) {
        sort(Sorter.getSorter(sorter));
    }

    public void sort(@NotNull Sorter sorter1, @NotNull Sorter sorter2) {
        sort(Sorter.getSorter(sorter1, sorter2));
    }

    public void sort(@NotNull Sorter sorter1, @NotNull Sorter sorter2, @NotNull Sorter sorter3) {
        sort(Sorter.getSorter(sorter1, sorter2, sorter3));
    }

    //实现MySQL8.0版本中的dense_rank函数，前提是先将dataset按照指定字段和期望排列的顺序排好序，再开始计算排名rank
    @SuppressWarnings("all")
    public <T, R> DataSet dense_rank(String groupBy, String field) {
        List<Integer> rnks = new ArrayList<>();
        int rnk = 0;
        T p1 = (colType(groupBy).equals(String.class)) ? (T) "" : null;
        R p2 = (colType(field).equals(String.class)) ? (R) "" : null;
        for (Row row : data) {
            T group_val = row.value(groupBy);
            R field_val = row.value(field);
            rnk = (!group_val.equals(p1)) ? 1 : ((field_val.equals(p2)) ? rnk : rnk + 1);
            p1 = group_val;
            p2 = field_val;
            rnks.add(rnk);
        }
        return withColumn(StructType.createStructType("rank", Integer.class), rnks);
    }

    @SuppressWarnings("all")
    public <T, R, S> DataSet dense_rank(String groupBy, String field1, String field2) {
        List<Integer> rnks = new ArrayList<>();
        int rnk = 0;
        T p1 = (colType(groupBy).equals(String.class)) ? (T) "" : null;
        R p2 = (colType(field1).equals(String.class)) ? (R) "" : null;
        S p3 = (colType(field2).equals(String.class)) ? (S) "" : null;
        for (Row row : data) {
            T group_val = row.value(groupBy);
            R field1_val = row.value(field1);
            S field2_val = row.value(field2);
            rnk = (!group_val.equals(p1)) ? 1 : ((field1_val.equals(p2)) ? rnk : ((field2_val.equals(p3)) ? rnk : rnk + 1));
            p1 = group_val;
            p2 = field1_val;
            p3 = field2_val;
            rnks.add(rnk);
        }
        return withColumn(StructType.createStructType("rank", Integer.class), rnks);
    }

    //select *
    public DataSet select() {
        return this;
    }

    //按照列名select
    public DataSet select(String... cols) {
        return map(row -> row.select(cols));
    }

    //按照列号select，列号从0开始
    public DataSet select(int... Indexes) {
        return map(row -> row.select(Indexes));
    }

    public DataSet join(@NotNull DataSet other, @NotNull String join_col) {
        return join(other, join_col,
                ComUtil.strArrNotContained(other.getColNames(), join_col));
    }

    public DataSet join(@NotNull DataSet other, @NotNull String join_col, String... colsInOtherToBeJoined) {
        return leftJoin(other, join_col, colsInOtherToBeJoined).filter(row -> {
            List<Object> joinData = row.select(colsInOtherToBeJoined).getData();
            return ComUtil.listFilter(joinData, Objects::nonNull).size() != 0;
        });
    }

    //默认的leftJoin，other中除了join_col字段，其余字段都进行连接
    public DataSet leftJoin(@NotNull DataSet other, @NotNull String join_col) {
        return leftJoin(other, join_col,
                ComUtil.strArrNotContained(other.getColNames(), join_col));
    }

    //默认的rightJoin，this中除了join_col字段，其余字段都进行连接
    public DataSet rightJoin(@NotNull DataSet other, @NotNull String join_col) {
        return other.leftJoin(this, join_col);
    }

    /**
     * @param other：要join的dataSet
     * @param join_col：需要join的列名
     * @param colsInOtherToBeJoined：选择other中需要join的列名
     * @return
     */
    public <T> DataSet leftJoin(@NotNull DataSet other, @NotNull String join_col, String... colsInOtherToBeJoined) {
        List<T> intersection = getColData(join_col);
        List<T> right = other.getColData(join_col);
        intersection.retainAll(right);
        DataSet select = other.select(colsInOtherToBeJoined);
        List<Row> select_data = select.getData();
        return map(row -> {
            T value = row.value(join_col);
            if (intersection.contains(value)) {
                row.merge(select_data.get(right.indexOf(value)));
            } else {
                int size = colsInOtherToBeJoined.length;
                List<Object> data = new ArrayList<>(size);
                for (int i = 0; i < size; i++) {
                    data.add(null);
                }
                row.merge(Row.createRow(select.schema, data));
            }
            return row;
        });
    }

    public DataSet rightJoin(@NotNull DataSet other, @NotNull String join_col, String... colsInThisToBeJoined) {
        return other.leftJoin(this, join_col, colsInThisToBeJoined);
    }

    //1列重命名
    public void rename(String old_col, String new_col) {
        forEach(row -> row.alias(old_col, new_col));
        setSchema();
    }

    //多列重命名
    public void rename(String[] old_cols, String... new_cols) {
        forEach(row -> row.alias(old_cols, new_cols));
        setSchema();
    }

    //新增一列
    public DataSet withColumn(StructType structType, List<?> data) {
        row_number = 0;
        StructField structField = structType.getStructFields().get(0);
        if (!structField.getDataType().toString().equals(data.get(0).getClass().toString())) {
            throw new IllegalArgumentException("the class of structType should be in line with that of the element of data");
        }

        DataSet withColumn_dataSet = map(row -> {
            row.add(structType, data.get(row_number));
            row_number++;
            return row;
        });
        setRow_number(0);
        return withColumn_dataSet;
    }

    /**
     * 自定义新增一列或多列
     */
    public DataSet withColumn(StructType structType, Function<Row, List<Object>> mapper) {
        return map(row -> {
            row.add(structType, mapper.apply(row));
            return row;
        });
    }

    public <T> void asType(String colName, Class<T> type) {
        int col_id = getColIndex(colName);
        data.forEach(row -> {
            row.getSchema().getStructFields().set(col_id, StructField.createStructField(colName, type));
            Object value = row.value(colName);
            if (Objects.nonNull(value)) {
                row.getData().set(col_id, ConvertUtil.toAny(value, type));
            }
        });
        setSchema();
    }

    //新增一列自增id（从0开始）
    public DataSet addIncrementColumn() {
        StructType structType = StructType.createStructType("idx", Integer.class);
        List<Integer> ids = new ArrayList<>();
        row_number = 0;
        forEach(row -> {
            ids.add(row_number);
            row_number++;
        });
        setRow_number(0);
        return withColumn(structType, ids);
    }

    //将m*n维的DataSet进行转置，变成一个2*(n*m)维的DataSet，schema={"colName" : String, "colValue" : type}
    //即把DataSet每行数据都进行转置
    public <T> DataSet transpose(String colName, String valueName, Class<T> valType) {
        DataSet dataSet = DataSet.create();
        List<String> colNames = getColNames();
        int size = colSize();
        StructType structType = StructType.createStructType(new String[]{colName, valueName}, String.class, valType);
        forEach(row1 -> {
            List<Object> rowData = row1.getData();
            for (int i = 0; i < size; i++) {
                Object val;
                if (valType.equals(Object.class)) {
                    val = rowData.get(i);
                } else {
                    val = ConvertUtil.toAny(rowData.get(i), valType);
                }
                dataSet.data.add(Row.createRow(structType, colNames.get(i), val));
            }
        });
        dataSet.setSchema();
        return dataSet;
    }

    //按照每列已有类型用默认值填充null
    public void fillNull() {
        List<Class<?>> colClasses = getColClasses();
        int size = colClasses.size();
        data.forEach(row -> {
            for (int i = 0; i < size; i++) {
                Object o = row.get(i);
                if (Objects.isNull(o)) {
                    row.getData().set(i, ConvertUtil.toAny(o, colClasses.get(i)));
                }
            }
        });
    }

    public GroupDataSet groupBy(String... colNames) {
        GroupDataSet groupDataSet = GroupDataSet.create();
        List<Tuple2<Row, List<Row>>> groupData = new ArrayList<>();
        Map<Row, List<Row>> tmpMap = new LinkedHashMap<>();
        String[] cols = ComUtil.strArrNotContained(getColNames(), colNames);
        forEach(row -> {
            Row keyRow = row.select(colNames);
            Row select = row.select(cols);
            tmpMap.compute(keyRow, (k, v) -> {
                if (Objects.isNull(v)) {
                    v = new ArrayList<>(Collections.singletonList(select));
                } else {
                    v.add(select);
                }
                return v;
            });
        });
        tmpMap.forEach((row, rows) -> groupData.add(Tuple2.of(row, rows)));
        Tuple2<Row, List<Row>> tuple2 = groupData.get(0);
        groupDataSet.setSchema_1(tuple2._1().getSchema());
        groupDataSet.setSchema_2(tuple2._2().get(0).getSchema());
        groupDataSet.setGroupData(groupData);
        return groupDataSet;
    }

    //将dataset数据集根据所给的bean对象类型转换为list实体集合，为写入MySQL做准备
    public <T> List<T> getJavaBeanDataSet(Class<T> javaBeanType) {
        List<T> javaBeans = new ArrayList<>();
        T t;
        try {
            for (Map<String, Object> item : getMapData()) {
                t = javaBeanType.newInstance();
                for (Map.Entry<String, Object> entry : item.entrySet()) {
                    String k = entry.getKey();
                    String setMethod = "set" + k.substring(0, 1).toUpperCase() + k.substring(1);
                    Method set = javaBeanType.getDeclaredMethod(setMethod, colType(k));
                    set.invoke(t, entry.getValue());
                }
                javaBeans.add(t);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return javaBeans;
    }

    public List<Map<String, Object>> getMapData() {
        List<Map<String,Object>> data =new ArrayList<>();
        List<String> colNames = getColNames();
        int size = colNames.size();
        forEach(row -> {
            List<Object> rowData = row.getData();
            Map<String, Object> map = new LinkedHashMap<>();
            for (int i = 0; i < size; i++) {
                map.put(colNames.get(i), rowData.get(i));
            }
            data.add(map);
        });
        return data;
    }

    /*//将dataset数据集写入MySQL中
    @SuppressWarnings("all")
    public int toSql(NameSpace nameSpace, String sql_id) {
        return sqlSession.insert(nameSpace.getPath() + sql_id, getMapData());
    }

    @SuppressWarnings("all")
    public <T> int toSql(Class<T> javaBeanType, NameSpace nameSpace, String sql_id) {
        List<T> javaBeans = getJavaBeanDataSet(javaBeanType);
        return sqlSession.insert(nameSpace.getPath() + sql_id, javaBeans);
    }*/

    //将dataset数据集写入MySQL中
//    public int toSql(String table_name) {
//        if (!SqlUtil.tableExist(table_name)) {
//            SqlUtil.createTable(SqlUtil.createSql(table_name, getColNames(), getColClasses()));
//        }
//        List<String> sqlList =new ArrayList<>();
//        for (Row row : data) {
//            sqlList.add(SqlUtil.insertSql(table_name, getColNames(), row.getData()));
//        }
//        return SqlUtil.batchInsert(sqlList);
//    }

    //将dataset数据集写入CSV文件中
    public void writeCSV(String csvFilePath) {
        writeCSV(csvFilePath, false);
    }

    public void writeCSV(String csvFilePath, Boolean header) {
        writeCSV(csvFilePath, header, ',');
    }

    public void writeCSV(String csvFilePath, Boolean header, char sep) {
        writeCSV(csvFilePath, header, sep, StandardCharsets.UTF_8);
    }

    public void writeCSV(String csvFilePath, Boolean header, char sep, Charset charset) {
        String[] arr = getColNames().toArray(new String[0]);
        String[] csvHeaders = header ? arr : null;
        CsvUtil.writeCSV(getMapData(), csvFilePath, csvHeaders, sep, charset);
    }

    public DataSet copy() {
        return Kryo.get().copy(this);
    }

    public void printSchema() {
        getData().get(0).printSchema();
    }

    public void print() {
        this.forEach(System.out::println);
    }

    @Override
    public String toString() {
        return StringUtils.join(data, "\n");
    }


}

