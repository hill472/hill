package org.example.util;

import com.csvreader.CsvReader;
import com.csvreader.CsvWriter;

import java.io.File;
import java.io.IOException;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.Map;

/**
 * Created with IntelliJ IDEA.
 *
 * @Author: HillHuang
 * @Date: 2021/09/23/8:58
 * @Description:
 */
public class CsvUtil {

    public static <T> void writeCSV(Collection<T> dataSet, String csvFilePath) {
        writeCSV(dataSet, csvFilePath, null, ',', StandardCharsets.UTF_8);
    }

    public static <T> void writeCSV(Collection<T> dataSet, String csvFilePath, String[] csvHeaders) {
        writeCSV(dataSet, csvFilePath, csvHeaders, ',', StandardCharsets.UTF_8);
    }

    public static <T> void writeCSV(Collection<T> dataSet, String csvFilePath, String[] csvHeaders, char sep) {
        writeCSV(dataSet, csvFilePath, csvHeaders, sep, StandardCharsets.UTF_8);
    }

    @SuppressWarnings("all")
    public static <T> void writeCSV(Collection<T> dataSet, String csvFilePath, String[] csvHeaders, char sep, Charset charset) {
        try {
            // 定义路径，分隔符，编码
            File file = new File(csvFilePath);
            if (file.exists()) {
                file.delete();
                file.createNewFile();
            }

            CsvWriter csvWriter = new CsvWriter(csvFilePath, sep, charset);
            // 写表头
            csvWriter.writeRecord(csvHeaders);
            // 遍历集合,写内容
            for (T t : dataSet) {
                if (t instanceof Map) {
                    Map<String, Object> mapData = (Map<String, Object>) t;
                    List<String> tmp = new ArrayList<>();
                    mapData.forEach((k,v) -> tmp.add(v.toString()));
                    String[] csvContent = tmp.toArray(new String[0]);
                    //迭代插入记录
                    csvWriter.writeRecord(csvContent);
                } else {
                    //获取类属性
                    Class<?> clz = t.getClass();
                    Field[] fields = clz.getDeclaredFields();
                    int length = fields.length;
                    String[] csvContent = new String[length];
                    for (short i = 0; i < length; i++) {
                        Field field = fields[i];
                        String fieldName = field.getName();
                        String getMethodName = "get"
                                + fieldName.substring(0, 1).toUpperCase()
                                + fieldName.substring(1);
                        try {
                            Method getMethod = clz.getMethod(getMethodName);
                            Object value = getMethod.invoke(t);
                            if (value == null) {
                                continue;
                            }
                            //取值并赋给数组
                            csvContent[i] = value.toString();
                        } catch (Exception e) {
                            e.getStackTrace();
                        }
                    }
                    //迭代插入记录
                    csvWriter.writeRecord(csvContent);
                }
            }
            csvWriter.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public static List<String[]> readCSV(String csvFilePath, Boolean header, char sep, Charset charset) {
        List<String[]> csvList = new ArrayList<>();
        try {
            CsvReader reader = new CsvReader(csvFilePath, sep, charset);

            if (header) {
                reader.readHeaders();
            }

            while (reader.readRecord()) {
                csvList.add(reader.getValues());
            }

            reader.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return csvList;
    }

    public static List<String[]> readCSV(String csvFilePath, Boolean header, char sep) {
        return readCSV(csvFilePath, header, sep, StandardCharsets.UTF_8);
    }

    public static List<String[]> readCSV(String csvFilePath, Boolean header) {
        return readCSV(csvFilePath, header, ',');
    }

    public static List<String[]> readCSV(String csvFilePath) {
        return readCSV(csvFilePath, false);
    }


}
