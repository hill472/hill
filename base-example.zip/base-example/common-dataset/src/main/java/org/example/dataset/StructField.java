package org.example.dataset;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

import java.io.Serializable;
import java.util.Objects;

/**
 * Created with IntelliJ IDEA.
 *
 * @Author: HillHuang
 * @Date: 2021/10/15/11:34
 * @Description:
 */
@NoArgsConstructor
@Setter
@Getter
@ToString
public class StructField implements Serializable {
    private String name;
    private Class<?> dataType;

    private StructField(String name, Class<?> dataType) {
        this.name = name;
        this.dataType = dataType;
    }

    public static StructField createStructField(String name, Class<?> dataType) {
        if (name == null) {
            throw new IllegalArgumentException("name should not be null.");
        }
        if (dataType == null) {
            throw new IllegalArgumentException("dataType should not be null.");
        }
        return new StructField(name, dataType);
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        StructField that = (StructField) o;
        return name.equals(that.name) && dataType.getName().equals(that.dataType.getName());
    }

    @Override
    public int hashCode() {
        return Objects.hash(name, dataType);
    }
}
