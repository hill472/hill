package org.example.util;



import java.util.Objects;

/**
 * Created with IntelliJ IDEA.
 *
 * @Author: HillHuang
 * @Date: 2021/09/23/15:58
 * @Description: 数据类型转换工具类
 */
public class ConvertUtil {
    /**
     * <将obj转换为string，如果obj为null则返回defaultVal>
     *
     * @param obj 需要转换为string的对象
     * @return obj转换为string
     */

    public static String toString(Object obj) {
        return obj != null ? obj.toString() : "";
    }

    public static Boolean can_convert(Object obj) {
       return obj != null && !Objects.equals(obj, "");
    }

    /**
     * <将对象转换为int>
     *
     * @param obj 需要转换为int的对象
     * @return obj转换成的int值
     */
    public static Integer toInt(Object obj) {
        if (can_convert(obj))
            return 0;
        String str_value = obj.toString();
        if (str_value.contains(".")) {
            return toDouble(str_value).intValue();
        }
        return Integer.parseInt(str_value);
    }

    /**
     * <将对象转换为Float>
     *
     * @param obj 需要转换为Float的对象
     * @return obj转换成的Float值
     */
    public static Float toFloat(Object obj) {
        return can_convert(obj) ? Float.parseFloat(obj.toString()) : 0f;
    }

    public static Long toLong(Object obj) {
        return can_convert(obj) ? Long.parseLong(obj.toString()) : 0L;
    }

    /**
     * 将object转换为double类型，如果出错则返回 defaultVal
     *
     * @param obj 需要转换的对象
     * @return 转换后的结果
     */
    public static Double toDouble(Object obj) {
        return can_convert(obj) ? Double.parseDouble(obj.toString()) : 0d;
    }


    public static <T> Object toAny(Object obj, Class<T> clz) {
        String clzName = clz.getName();
        if ("java.lang.Double".equals(clzName)) {
            return toDouble(obj);
        }
        if ("java.lang.Float".equals(clzName)) {
            return toFloat(obj);
        }
        if ("java.lang.Integer".equals(clzName)) {
            return toInt(obj);
        }
        if ("java.lang.Long".equals(clzName)) {
            return toLong(obj);
        }
        if ("java.lang.String".equals(clzName)) {
            return toString(obj);
        }
        return null;
    }

}

