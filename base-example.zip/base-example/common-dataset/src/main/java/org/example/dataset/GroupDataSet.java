package org.example.dataset;

import com.esotericsoftware.kryo.Kryo;
import org.example.model.Tuple2;
import org.example.util.ConvertUtil;
import lombok.Data;
import org.apache.commons.lang3.StringUtils;

import javax.validation.constraints.NotNull;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;

/**
 * Created with IntelliJ IDEA.
 *
 * @Author: HillHuang
 * @Date: 2021/10/05/13:49
 * @Description:
 */
@Data
public class GroupDataSet implements Serializable {

    private List<Tuple2<Row, List<Row>>> groupData;
    private Tuple2<StructType, StructType> groupSchema;

    private static final ThreadLocal<Kryo> Kryo = ThreadLocal.withInitial(() -> {
        Kryo kryo = new Kryo();
        kryo.setRegistrationRequired(false);
        return kryo;
    });

    private GroupDataSet() {
        this.groupData = new ArrayList<>();
        this.groupSchema = Tuple2.of(StructType.create(), StructType.create());
    }

    private GroupDataSet(Tuple2<StructType, StructType> groupSchema, List<Tuple2<Row, List<Row>>> groupData) {
        this.groupData = groupData;
        this.groupSchema = groupSchema;
    }

    public static GroupDataSet create() {
        return new GroupDataSet();
    }

    public static GroupDataSet createGroupDataSet(
            @NotNull Tuple2<StructType, StructType> groupSchema,
            @NotNull List<Tuple2<Row, List<Row>>> groupData) {
        StructType schema_1 = groupData.get(0)._1().getSchema();
        StructType schema_2 = groupData.get(0)._2().get(0).getSchema();
        if (!groupSchema._1().equals(schema_1) || !groupSchema._2().equals(schema_2)) {
            throw new IllegalArgumentException("please check the schema of data");
        }
        return new GroupDataSet(groupSchema, groupData);
    }

    public DataSet count() {
        DataSet dataSet = DataSet.create();
        List<Row> data = dataSet.getData();
        StructType cntSchema = schema_1().add("count", Integer.class);
        groupData.forEach(tuple2 -> {
            List<Object> rowData = new ArrayList<>(tuple2._1().getData());
            int size = tuple2._2().size();
            rowData.add(size);
            data.add(Row.createRow(cntSchema, rowData));
        });
        return dataSet;
    }

    public DataSet sum(String col) {
        DataSet dataSet = DataSet.create();
        List<Row> data = dataSet.getData();
        StructType sumSchema = schema_1().add("sum", Double.class);
        groupData.forEach(tuple2 -> {
            List<Object> rowData = new ArrayList<>(tuple2._1().getData());
            double s = tuple2._2().stream().mapToDouble(row -> ConvertUtil.toDouble(row.get(col))).sum();
            rowData.add(s);
            data.add(Row.createRow(sumSchema, rowData));
        });
        return dataSet;
    }

    public DataSet max(String col) {
        DataSet dataSet = DataSet.create();
        List<Row> data = dataSet.getData();
        StructType maxSchema = schema_1().add("max", Double.class);
        groupData.forEach(tuple2 -> {
            List<Object> rowData = new ArrayList<>(tuple2._1().getData());
            double s = tuple2._2().stream().mapToDouble(row -> ConvertUtil.toDouble(row.get(col)))
                    .max().orElse(0.0);
            rowData.add(s);
            data.add(Row.createRow(maxSchema, rowData));
        });
        return dataSet;
    }

    public DataSet min(String col) {
        DataSet dataSet = DataSet.create();
        List<Row> data = dataSet.getData();
        StructType minSchema = schema_1().add("min", Double.class);
        groupData.forEach(tuple2 -> {
            List<Object> rowData = new ArrayList<>(tuple2._1().getData());
            double s = tuple2._2().stream().mapToDouble(row -> ConvertUtil.toDouble(row.get(col)))
                    .min().orElse(0.0);
            rowData.add(s);
            data.add(Row.createRow(minSchema, rowData));
        });
        return dataSet;
    }

    public DataSet avg(String col) {
        DataSet dataSet = DataSet.create();
        List<Row> data = dataSet.getData();
        StructType minSchema = schema_1().add("average", Double.class);
        groupData.forEach(tuple2 -> {
            List<Object> rowData = new ArrayList<>(tuple2._1().getData());
            double s = tuple2._2().stream().mapToDouble(row -> ConvertUtil.toDouble(row.get(col)))
                    .average().orElse(0.0);
            rowData.add(s);
            data.add(Row.createRow(minSchema, rowData));
        });
        return dataSet;
    }

    //分组后按照多字段自定义排序
    public void sort(Comparator<Row> cpt) {
        groupData.forEach(tuple2 -> tuple2._2().sort(cpt));
    }

    public void sort(Sorter sorter) {
        sort(Sorter.getSorter(sorter));
    }

    public void sort(Sorter sorter1, Sorter sorter2) {
        sort(Sorter.getSorter(sorter1, sorter2));
    }

    public void sort(Sorter sorter1, Sorter sorter2, Sorter sorter3) {
        sort(Sorter.getSorter(sorter1, sorter2, sorter3));
    }

    /**
     * groupBy之后按照指定列进行合并，若不传参数，则合并所有列
     *
     * @param colsToBeConcat
     * @param sep
     * @return
     */
    public DataSet groupConcat(String[] colsToBeConcat, String sep) {
        schema_2().getStructFields().forEach(structField -> structField.setDataType(String.class));
        StructType structType = schema_1().merge(schema_2().select(colsToBeConcat));

        List<Row> newRows = this.groupData.stream().flatMap(tuple2 -> {
            List<Row> rows = tuple2._2();
            List<Row> newRowValues = new ArrayList<>();
            Row newRow = Row.create();
            for (String s : colsToBeConcat) {
                List<Object> tmp = new ArrayList<>();
                rows.forEach(row -> tmp.add(row.get(s)));
                newRow.add(StructType.createStructType(s, String.class), StringUtils.join(tmp, sep));
            }
            tuple2._1().add(newRow.getSchema(), newRow.getData());
            newRowValues.add(tuple2._1());
            return newRowValues.stream();
        }).collect(Collectors.toList());

        return DataSet.createDataSet(structType, newRows);
    }

    public DataSet groupConcat(String... colsToBeConcat) {
        return groupConcat(colsToBeConcat, ",");
    }

    public DataSet groupConcat() {
        String[] colsToBeConcat = groupData.get(0)._2().get(0).getColNames().toArray(new String[0]);
        return groupConcat(colsToBeConcat, ",");
    }

    /**
     * groupBy之后按照指定列进行展平，若不传参数，则展平所有列
     *
     * @param colsToBeExploded
     * @return
     */
    public DataSet explode(String... colsToBeExploded) {
        StructType structType = schema_1().merge(schema_2().select(colsToBeExploded));
        List<Row> rows = this.groupData.stream().flatMap(tuple2 -> {
            Row row = tuple2._1();
            return tuple2._2().stream().map(row1 -> {
                Row r = row1.select(colsToBeExploded);
                row.add(r.getSchema(), r.getData());
                return row;
            });
        }).collect(Collectors.toList());
        return DataSet.createDataSet(structType, rows);
    }

    public DataSet explode() {
        String[] colsToBeExploded = groupData.get(0)._2().get(0).getColNames().toArray(new String[0]);
        return explode(colsToBeExploded);
    }

    public List<Row> getKeyValues() {
        return groupData.stream().map(Tuple2::_1).collect(Collectors.toList());
    }

    public List<List<Row>> getRowValues() {
        return groupData.stream().map(Tuple2::_2).collect(Collectors.toList());
    }

    public GroupDataSet copy() {
        return Kryo.get().copy(this);
    }


    public StructType schema_1() {
        return groupSchema._1();
    }

    public StructType schema_2() {
        return groupSchema._2();
    }

    public void setSchema_1(StructType schema_1) {
        groupSchema.setValue1(schema_1);
    }

    public void setSchema_2(StructType schema_2) {
        groupSchema.setValue2(schema_2);
    }

    public void print() {
        groupData.forEach(System.out::println);
    }

}


