package org.example.util;

import com.google.common.collect.Lists;
import org.apache.commons.lang3.StringUtils;

import java.lang.reflect.Array;
import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;
import java.util.function.Function;
import java.util.function.Predicate;
import java.util.stream.Collectors;

/**
 * Created with IntelliJ IDEA.
 *
 * @Author: HillHuang
 * @Date: 2021/09/04/13:07
 * @Description: CommonUtil
 */
public class ComUtil {

    @SuppressWarnings("all")
    public static <T> List<T> createData(T... objs) {
        return Lists.newArrayList(objs);
    }

    //列表过滤器，指定一个元素集合，按照某种条件过滤
    @SuppressWarnings("all")
    public static <T> List<T> listFilter(List<T> list, Predicate<T> predicate, T... ts) {
        List<T> collect = list.stream().filter(predicate).collect(Collectors.toList());
        List<T> listRes = Optional.ofNullable(collect).orElseGet(() -> new ArrayList<>());
        return listRes;
    }

    //列表过滤器，按照某种条件过滤
    @SuppressWarnings("all")
    public static <T> List<T> listFilter(List<T> list, Predicate<T> predicate) {
        List<T> collect = list.stream().filter(t -> predicate.test(t)).collect(Collectors.toList());
        List<T> listRes = Optional.ofNullable(collect).orElseGet(() -> new ArrayList<>());
        return listRes;
    }

    //列表过滤器，过滤到集合ts中的元素
    @SuppressWarnings("all")
    public static <T> List<T> listNotContainsFilter(List<T> list, T... ts) {
        List<T> rs1 = Arrays.asList(ts);
        return listFilter(list, t -> !rs1.contains(t), ts);
    }

    //列表过滤器，仅保留集合ts中包含的元素
    @SuppressWarnings("all")
    public static <T> List<T> listContainsFilter(List<T> list, T... ts) {
        List<T> rs1 = Arrays.asList(ts);
        return listFilter(list, t -> rs1.contains(t), ts);
    }

    @SuppressWarnings("all")
    public static <T> T[] arrFilter(List<T> list, Predicate<T> predicate, Class<T> clz) {
        List<T> tList = listFilter(list, predicate);
        int size = tList.size();
        T[] resArr = (T[]) Array.newInstance(clz, size);
        for (int i = 0; i < size; i++) {
            resArr[i] = tList.get(i);
        }
        return resArr;
    }

    @SuppressWarnings("all")
    public static <T> T[] arrFilter(List<T> list, Predicate<T> predicate, Class<T> clz, T... ts) {
        List<T> tList = listFilter(list, predicate);
        int size = tList.size();
        T[] resArr = (T[]) Array.newInstance(clz, size);
        for (int i = 0; i < size; i++) {
            resArr[i] = tList.get(i);
        }
        return resArr;
    }

    @SuppressWarnings("all")
    public static <T> T[] arrNotContainsFilter(List<T> list, Class<T> clz, T... ts) {
        List<T> rs1 = Arrays.asList(ts);
        return arrFilter(list, t -> !rs1.contains(t), clz, ts);
    }

    public static String[] strArrNotContained(List<String> list, String... notContains) {
        return arrNotContainsFilter(list, String.class, notContains);
    }

    public static String[] strArrContained(List<String> list, String... contains) {
        return arrContainsFilter(list, String.class, contains);
    }

    @SuppressWarnings("all")
    public static <T> T[] arrContainsFilter(List<T> list, Class<T> clz, T... ts) {
        List<T> rs1 = Arrays.asList(ts);
        return arrFilter(list, t -> rs1.contains(t), clz, ts);
    }

    @SuppressWarnings("all")
    public static <T, R> List<R> listTransformer(List<T> list, Function<T, R> mapper) {
        List<R> collect = list.stream().map(t -> mapper.apply(t)).collect(Collectors.toList());
        List<R> listRes = Optional.ofNullable(collect).orElseGet(() -> {
            List<R> ts1 = new ArrayList<>();
            return ts1;
        });
        return listRes;
    }

    @SuppressWarnings("all")
    public static <T, R> R[] arrTransformer(List<T> list, Function<T, R> mapper, Class<R> clz) {
        List<R> tList = listTransformer(list, mapper);
        int size = tList.size();
        R[] resArr = (R[]) Array.newInstance(clz, size);
        for (int i = 0; i < size; i++) {
            resArr[i] = tList.get(i);
        }
        return resArr;
    }

    public static <T> String mkString(Iterable<T> iterable, String sep) {
        return StringUtils.join(iterable, sep);
    }

    public static <T> T createJavaBean(List<Object> data, Class<T> clz) {
        T t = null;
        try {
            t = clz.newInstance();
            Field[] fields = clz.getDeclaredFields();
            int length = fields.length;
            if (length != data.size()) {
                throw new IllegalArgumentException("the size of data should be equal to the length of clz of fields");
            }
            for (int i = 0; i < length; i++) {
                Field field = fields[i];
                field.setAccessible(true);
                field.set(t, data.get(i));
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return t;
    }

    public static <T> List<T> createJavaBeanList(List<String[]> dataSet, Class<T> clz) {
        Field[] fields = clz.getDeclaredFields();
        int len = fields.length;
        if (len != dataSet.get(0).length) {
            throw new IllegalArgumentException("the length of types parameter is not correct");
        }
        List<T> javaBeanList = new ArrayList<>();
        dataSet.forEach(strings -> {
            List<Object> tmp = new ArrayList<>();
            for (int i = 0; i < len; i++) {
                Class<?> type = fields[i].getType();
                String value = strings[i].equals("null") ? null :
                        type == String.class ? strings[i] : StringUtils.strip(strings[i]);
                Object o = ConvertUtil.toAny(value, type);
                tmp.add(o);
            }
            javaBeanList.add(createJavaBean(tmp, clz));
        });
        return javaBeanList;
    }

}
