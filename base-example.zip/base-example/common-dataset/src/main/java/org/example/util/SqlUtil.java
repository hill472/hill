//package org.example.util;
//
//import com.alibaba.fastjson.JSONObject;
//import org.example.model.NameSpace;
//import org.apache.ibatis.session.ExecutorType;
//import org.apache.ibatis.session.SqlSession;
//import org.mybatis.spring.SqlSessionTemplate;
//import org.springframework.beans.factory.annotation.Value;
//import org.springframework.stereotype.Component;
//
//import javax.annotation.PostConstruct;
//import javax.annotation.Resource;
//import java.util.Date;
//import java.util.List;
//import java.util.Objects;
//
///**
// * Created with IntelliJ IDEA.
// * 注意该类必须要配合SpringBoot一起使用，并且需要声明
// *
// * @Author: HillHuang
// * @Date: 2021/11/30/14:43
// * @Description:
// */
//@Component
//public class SqlUtil {
//    @Resource
//    SqlSessionTemplate sqlSessionTemplate;
//
//    @Value("${name_space:}")
//    String name_space; //工程中resources目录下mapper.xml文件中的name_space
//
//    private static SqlSessionTemplate sqlSession;
//
//    private static String DEFAULT_PATH;
//
//    private final static Integer COMMIT = 1000;
//
//    @PostConstruct
//    public void init() {
//        sqlSession = this.sqlSessionTemplate;
//        DEFAULT_PATH = name_space + ".";
//    }
//
//    public static String createSql(String tab_name, List<String> colNames, List<Class<?>> classes, Boolean primary_key) {
//        Class<?> type;
//        String column;
//        StringBuilder sb = new StringBuilder();
//        List<?> numClz = ComUtil.createData(Integer.class, Long.class, Short.class, int.class, long.class, short.class);
//        sb.append("create table ").append(tab_name).append(" ( \r\n");
//        if(primary_key) {
//            sb.append("    id bigint(10) NOT NULL PRIMARY KEY AUTO_INCREMENT,\n");
//        }
//        int length = colNames.size();
//        for (int k = 0; k < length; k++) {
//            column = colNames.get(k);
//            sb.append("    ").append(column).append(" ");
//            type = classes.get(k);
//            if(numClz.contains(type)){
//                sb.append("bigint(10) NULL DEFAULT NULL");
//            }else if(type == Double.class || type == Float.class){
//                sb.append("double(10, 4) NULL DEFAULT NULL");
//            }else if(type == Date.class){
//                sb.append("timestamp DEFAULT CURRENT_TIMESTAMP");
//            }
//            else{
//                sb.append("text NULL DEFAULT NULL");
//            }
//            if (k != length-1)
//                sb.append(",\n");
//        }
//        sb.append("\n) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = COMPACT");
//        return sb.toString();
//    }
//
//    public static String createSql(String table_name, List<String> colNames, List<Class<?>> classes) {
//        return createSql(table_name, colNames, classes,false);
//    }
//
//    public static String insertSql(String tab_name, List<String> colNames, List<Object> data) {
//        String value = JSONObject.toJSONString(data);
//        return "insert into " + tab_name + "\r\n" +
//                "    " + "(" + ComUtil.mkString(colNames, ",") + ")" + "\r\n" +
//                "values" + "\r\n" +
//                "    "+ "(" + value.substring(1, value.length()-1) + ")";
//    }
//
//    public static int createTable(String sql) {
//        return sqlSession.update( DEFAULT_PATH + "createTable", sql);
//    }
//
//    public static Boolean tableExist(String table_name) {
//        return !Objects.isNull(selectOne("tableExist", table_name));
//    }
//
//    public static int update(String sql_id, Object param) {
//       return sqlSession.update(DEFAULT_PATH + sql_id, param);
//    }
//
//    public static <E> List<E> selectList(String sql_id, Object param) {
//       return sqlSession.selectList(DEFAULT_PATH + sql_id, param);
//    }
//
//    public static <E> List<E> selectList(String sql_id) {
//        return selectList(sql_id, null);
//    }
//
//    public static <T> T selectOne(String sql_id, Object param) {
//        return sqlSession.selectOne(DEFAULT_PATH + sql_id, param);
//    }
//
//    public static <T> T selectOne(String sql_id) {
//        return selectOne(sql_id, null);
//    }
//
//    public static <E> List<E> selectList(NameSpace nameSpace, String sql_id, Object param) {
//        return sqlSession.selectList(nameSpace.getPath() + sql_id, param);
//    }
//
//    public static <E> List<E> selectList(NameSpace nameSpace, String sql_id) {
//        return sqlSession.selectList(nameSpace.getPath() + sql_id, null);
//    }
//
//    public static <E> List<E> selectOne(NameSpace nameSpace, String sql_id, Object param) {
//        return sqlSession.selectList(nameSpace.getPath() + sql_id, param);
//    }
//
//    public static <E> List<E> selectOne(NameSpace nameSpace, String sql_id) {
//        return sqlSession.selectList(nameSpace.getPath() + sql_id, null);
//    }
//
//    public static void insert(String insert_sql) {
//        sqlSession.insert(DEFAULT_PATH + "insert", insert_sql);
//    }
//
//    public static int batchInsert(List<String> sqlList) {
//        int count = 0;
//        if (Objects.isNull(sqlList) || sqlList.size() == 0) {
//            return count;
//        }
//        int size = sqlList.size();
//        SqlSession batchSqlSession = null;
//        try {
//            batchSqlSession = sqlSession.getSqlSessionFactory().openSession(ExecutorType.BATCH, false);
//            String statement = DEFAULT_PATH + "insert";
//            for (int i = 0; i < size; i++) {
//                batchSqlSession.insert(statement, sqlList.get(i));
//                if (i == COMMIT || i == size - 1) {
//                    batchSqlSession.commit();
//                    batchSqlSession.clearCache();//清理缓存防止溢出
//                }
//            }
//            count = size;
//        } catch (Exception e) {
//            e.printStackTrace();
//            if (batchSqlSession != null) {
//                batchSqlSession.rollback();
//            }
//        } finally {
//            if (batchSqlSession != null) {
//                batchSqlSession.close();
//            }
//        }
//        return count;
//    }
//}
