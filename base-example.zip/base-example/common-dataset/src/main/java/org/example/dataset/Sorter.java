package org.example.dataset;

import org.example.util.ConvertUtil;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import javax.validation.constraints.NotNull;
import java.io.Serializable;
import java.util.Comparator;

/**
 * Created with IntelliJ IDEA.
 *
 * @Author: HillHuang
 * @Date: 2021/10/15/11:34
 * @Description:
 */
@Getter
@Setter
@EqualsAndHashCode
@ToString
public class Sorter implements Serializable {

    private final String field;
    private final Boolean ascending;

    protected Sorter(String field, Boolean ascending) {
        this.field = field;
        this.ascending = ascending;
    }

    public static Sorter createSorter(@NotNull String field, @NotNull Boolean ascending) {
        return new Sorter(field, ascending);
    }

    public static Sorter createSorter(@NotNull String field) {
        return new Sorter(field, true);
    }

    @SuppressWarnings("all")
    public static <T> Comparator<Row> getSorter(@NotNull Sorter sorter) {
        String field = sorter.getField();
        Boolean ascending = sorter.getAscending();
        return (row1, row2) -> {
            Class<T> colType = row1.colType(field);
            //为了避免null值，按照起类型转换为默认值
            Comparable row1_field_val = (Comparable) ConvertUtil.toAny(row1.value(field), colType);
            Comparable row2_field_val = (Comparable) ConvertUtil.toAny(row2.value(field), colType);
            return ascending ? row1_field_val.compareTo(row2_field_val) : row2_field_val.compareTo(row1_field_val);
        };
    }

    @SuppressWarnings("all")
    public static <T1, T2> Comparator<Row> getSorter(@NotNull Sorter sorter1, @NotNull Sorter sorter2) {
        String field1 = sorter1.getField();
        String field2 = sorter2.getField();
        Boolean ascending1 = sorter1.getAscending();
        Boolean ascending2 = sorter2.getAscending();
        return (row1, row2) -> {
            Class<T1> colType1 = row1.colType(field1);
            Class<T2> colType2 = row1.colType(field2);
            Comparable row1_field1_val = (Comparable) ConvertUtil.toAny(row1.value(field1), colType1);
            Comparable row2_field1_val = (Comparable) ConvertUtil.toAny(row2.value(field1), colType1);
            Comparable row1_field2_val = (Comparable) ConvertUtil.toAny(row1.value(field2), colType2);
            Comparable row2_field2_val = (Comparable) ConvertUtil.toAny(row2.value(field2), colType2);
            int sort1 = (ascending1) ? row1_field1_val.compareTo(row2_field1_val) : row2_field1_val.compareTo(row1_field1_val);
            int sort2 = (ascending2) ? row1_field2_val.compareTo(row2_field2_val) : row2_field2_val.compareTo(row1_field2_val);
            return sort1 == 0 ? sort2 : sort1;
        };
    }

    @SuppressWarnings("all")
    public static <T1, T2, T3> Comparator<Row> getSorter(@NotNull Sorter sorter1, @NotNull Sorter sorter2, @NotNull Sorter sorter3) {
        String field1 = sorter1.getField();
        String field2 = sorter2.getField();
        String field3 = sorter3.getField();
        Boolean ascending1 = sorter1.getAscending();
        Boolean ascending2 = sorter2.getAscending();
        Boolean ascending3 = sorter3.getAscending();
        return (row1, row2) -> {
            Class<T1> colType1 = row1.colType(field1);
            Class<T2> colType2 = row1.colType(field2);
            Class<T3> colType3 = row1.colType(field3);

            Comparable row1_field1_val = (Comparable) ConvertUtil.toAny(row1.value(field1), colType1);
            Comparable row2_field1_val = (Comparable) ConvertUtil.toAny(row2.value(field1), colType1);
            Comparable row1_field2_val = (Comparable) ConvertUtil.toAny(row1.value(field2), colType2);
            Comparable row2_field2_val = (Comparable) ConvertUtil.toAny(row2.value(field2), colType2);
            Comparable row1_field3_val = (Comparable) ConvertUtil.toAny(row1.value(field3), colType3);
            Comparable row2_field3_val = (Comparable) ConvertUtil.toAny(row2.value(field3), colType3);
            int sort1 = (ascending1) ? row1_field1_val.compareTo(row2_field1_val) : row2_field1_val.compareTo(row1_field1_val);
            int sort2 = (ascending2) ? row1_field2_val.compareTo(row2_field2_val) : row2_field2_val.compareTo(row1_field2_val);
            int sort3 = (ascending3) ? row1_field3_val.compareTo(row2_field3_val) : row2_field3_val.compareTo(row1_field3_val);
            return sort1 == 0 ? (sort2 == 0 ? sort3 : sort2) : sort1;
        };
    }
}
