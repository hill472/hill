package org.example.model;

import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 * tuple4结构封装.
 */
@Getter
@Setter
@NoArgsConstructor
@EqualsAndHashCode
public class Tuple4<T1, T2, T3, T4> {

    private T1 value1;
    private T2 value2;
    private T3 value3;
    private T4 value4;

    protected Tuple4(T1 value1, T2 value2, T3 value3, T4 value4) {
        this.value1 = value1;
        this.value2 = value2;
        this.value3 = value3;
        this.value4 = value4;
    }

    public void setValues(T1 value1, T2 value2, T3 value3, T4 value4) {
        setValue1(value1);
        setValue2(value2);
        setValue3(value3);
        setValue4(value4);
    }

    public T1 _1() {
        return getValue1();
    }

    public T2 _2() {
        return getValue2();
    }

    public T3 _3() {
        return getValue3();
    }

    public T4 _4() {
        return getValue4();
    }

    public static <T1, T2, T3, T4> Tuple4<T1, T2, T3, T4> of(T1 value1, T2 value2, T3 value3, T4 value4){
        return new Tuple4<>(value1, value2, value3, value4);
    }

    @Override
    public String toString() {
        return "Tuple4("
                + value1
                + ", " + value2
                + ", " + value3
                + ", " + value4
                + ")";
    }
}
