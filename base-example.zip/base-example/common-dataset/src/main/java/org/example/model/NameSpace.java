package org.example.model;

/**
 * Created with IntelliJ IDEA.
 *
 * @Author: HillHuang
 * @Date: 2021/11/15/16:00
 * @Description: NameSpace接口类，根据工程中的mapper.xml文件位置，
 * 自定义一个所有mapper的命名空间地址的常量枚举类NameSpaceEnum，并实现getPath方法，例如：
        public enum NameSpaceEnum {
            Mapper1("com.dao.Mapper1"),
            Mapper2("com.dao.Mapper2"),
            Mapper3("com.dao.Mapper3");

            public final String PATH;

            NameSpaceEnum(String nameSpace) {
                this.PATH = nameSpace+".";
            }
            @Override
            public String toString() {
                return PATH;
            }
        }
 */
public interface NameSpace {
    String getPath();
}
