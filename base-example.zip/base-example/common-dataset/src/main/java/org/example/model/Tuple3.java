package org.example.model;

import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 * tuple3结构封装.
 */
@Getter
@Setter
@NoArgsConstructor
@EqualsAndHashCode
public class Tuple3<T1, T2, T3> {

    private T1 value1;
    private T2 value2;
    private T3 value3;

    protected Tuple3(T1 value1, T2 value2, T3 value3) {
        this.value1 = value1;
        this.value2 = value2;
        this.value3 = value3;
    }

    public void setValues(T1 value1, T2 value2, T3 value3) {
        setValue1(value1);
        setValue2(value2);
        setValue3(value3);
    }

    public T1 _1() {
        return getValue1();
    }

    public T2 _2() {
        return getValue2();
    }

    public T3 _3() {
        return getValue3();
    }

    public static <T1, T2, T3> Tuple3<T1, T2, T3> of(T1 value1, T2 value2, T3 value3) {
        return new Tuple3<>(value1, value2, value3);
    }

    @Override
    public String toString() {
        return "Tuple3("
                + value1
                + ", " + value2
                + ", " + value3
                + ")";
    }
}
