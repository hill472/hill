package org.example.dataset;

import javax.validation.constraints.NotNull;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Objects;


public class Row implements Serializable {

    private StructType schema;
    private List<Object> data;

    //调用无参构造时，将schema和data初始化避免报空指针异常
    private Row() {
        StructType structType = StructType.create();
        List<Object> dt = new ArrayList<>();
        setSchema(structType);
        setData(dt);
    }

    private Row(@NotNull StructType _schema, @NotNull List<Object> _data) {
        this.schema = StructType.create();
        this.data = new ArrayList<>();
        int size = _data.size();
        List<StructField> structFields = new ArrayList<>();
        List<StructField> _structFields = _schema.getStructFields();
        for (int i = 0; i < size; i++) {
            StructField structField = _structFields.get(i);
            String name = structField.getName();
            Class<?> dataType = structField.getDataType();
            structFields.add(StructField.createStructField(name, dataType));
            data.add(_data.get(i));
        }
        setSchema(StructType.createStructType(structFields));
    }

    private Row(@NotNull StructType _schema, @NotNull Object... _data) {
        this.schema = StructType.create();
        this.data = new ArrayList<>();
        int size = _data.length;
        List<StructField> structFields = new ArrayList<>();
        List<StructField> _structFields = _schema.getStructFields();
        for (int i = 0; i < size; i++) {
            StructField structField = _structFields.get(i);
            String name = structField.getName();
            Class<?> dataType = structField.getDataType();
            structFields.add(StructField.createStructField(name, dataType));
            data.add(_data[i]);
        }
        setSchema(StructType.createStructType(structFields));
    }

    public static Row create() {
        return new Row();
    }

    public static Row createRow(@NotNull StructType _schema, @NotNull Object... _data) {
        int size = _data.length;
        if (size != _schema.getStructFields().size()) {
            throw new IllegalArgumentException("the length of data should be equal to the size of schema");
        }

        for (int i = 0; i < size; i++) {
            Object cur_data = _data[i];
            if (Objects.nonNull(cur_data)) {
                String schema_type = _schema.getStructFields().get(i).getDataType().toString();
                String data_type = cur_data.getClass().toString();
                if (!schema_type.equals(data_type) && !schema_type.equals("class java.lang.Object"))
                    throw new IllegalArgumentException("the datatype of schema should be in line with the datatype of data");
            }
        }
        return new Row(_schema, _data);
    }

    public static Row createRow(@NotNull StructType _schema, @NotNull List<Object> _data) {
        return createRow(_schema, _data.toArray());
    }

    //获取列数
    public Integer size() {
        return data.size();
    }

    //获取所有列的列名list
    public List<String> getColNames() {
        return schema.getColNames();
    }

    //获取所有列的类型list
    public List<Class<?>> getColClasses() {
        return schema.getColClasses();
    }

    //获取指定列名的值类型
    public Class<?> getColType(String colName) {
        return getColClasses().get(getColNames().indexOf(colName));
    }

    public Class<?> getColType(Integer i) {
        return getColClasses().get(i);
    }

    //获取指定列名的值类型
    @SuppressWarnings("all")
    public <T> Class<T> colType(String colName) {
        return (Class<T>) getColType(colName);
    }

    @SuppressWarnings("all")
    public <T> Class<T> colType(Integer i) {
        return (Class<T>) getColType(i);
    }

    //获取指定列名的索引号
    public Integer getColIndex(String colName) {
        return getColNames().indexOf(colName);
    }

    public Boolean getBoolean(String col) {
        return (Boolean) get(col);
    }

    public Byte getByte(String col) {
        return (Byte) get(col);
    }

    public Character getChar(String col) {
        return (Character) get(col);
    }

    public Short getShort(String col) {
        return (Short) get(col);
    }

    public Integer getInt(String col) {
        return (Integer) get(col);
    }

    public Double getDouble(String col) {
        return (Double) get(col);
    }

    public Float getFloat(String col) {
        return (Float) get(col);
    }

    public Long getLong(String col) {
        return (Long) get(col);
    }

    public String getString(String col) {
        return (String) get(col);
    }

    public Boolean getBoolean(Integer i) {
        return (Boolean) get(i);
    }

    public Byte getByte(Integer i) {
        return (Byte) get(i);
    }

    public Character getChar(Integer i) {
        return (Character) get(i);
    }

    public Short getShort(Integer i) {
        return (Short) get(i);
    }

    public Integer getInt(Integer i) {
        return (Integer) get(i);
    }

    public Double getDouble(Integer i) {
        return (Double) get(i);
    }

    public Float getFloat(Integer i) {
        return (Float) get(i);
    }

    public Long getLong(Integer i) {
        return (Long) get(i);
    }

    public String getString(Integer i) {
        return (String) get(i);
    }

    //按照列号获取
    public Object get(Integer col_id) {
        return data.get(col_id);
    }

    //按照列号，同时指定类型获取
    @SuppressWarnings("all")
    public <T> T get(Integer col_id, Class<T> clz) {
        return (T) get(col_id);
    }

    public Object get(String col_name) {
        if (!getColNames().contains(col_name))
            throw new IllegalArgumentException("the indexName " + col_name + " in a schema of Row is undefined.");
        return get(getColIndex(col_name));
    }

    //按照列名获取，同时指定类型获取
    @SuppressWarnings("all")
    public <T> T get(String col_name, Class<T> clz) {
        return (T) get(col_name);
    }

    //获取指定字段的值
    @SuppressWarnings("all")
    public <T> T value(String col_name) {
        Class<T> clz = (Class<T>) getColType(col_name);
        return get(col_name, clz);
    }

    public void merge(Row other) {
        add(other.schema, other.data);
    }

    //add方法，新增多个字段
    public void add(StructType _schema, Object... _data) {
        StructType merge = schema.merge(_schema);
        setSchema(merge);
        Collections.addAll(data, _data);
    }

    //add方法，新增多个字段
    public void add(StructType _schema, List<Object> _data) {
        add(_schema, _data.toArray());
    }

    //列的重命名，有返回值
    public void alias(String old_col, String new_col) {
        List<StructField> structFields = schema.getStructFields();
        int col_id = getColIndex(old_col);
        Class<?> dataType = getColType(old_col);
        structFields.set(col_id, StructField.createStructField(new_col, dataType));
        schema.setStructFields(structFields);

    }

    public void alias(String[] old_cols, String... new_cols) {
        int length = old_cols.length;
        List<StructField> structFields = schema.getStructFields();
        for (int i = 0; i < length; i++) {
            int col_id = getColIndex(old_cols[i]);
            Class<?> dataType = getColType(col_id);
            structFields.set(col_id, StructField.createStructField(new_cols[i], dataType));
        }
        schema.setStructFields(structFields);
    }

    //按照列名select
    public Row select(String... cols) {
        StructType _schema = StructType.create();
        List<Object> _data = new ArrayList<>();
        List<StructField> structFields = new ArrayList<>();
        for (String col : cols) {
            Class<?> clazz = getColType(col);
            _data.add(get(col, clazz));
            structFields.add(StructField.createStructField(col, clazz));
        }
        _schema.setStructFields(structFields);
        return createRow(_schema, _data);
    }

    //按照列号select，列号从0开始
    public Row select(int... Indexes) {
        StructType _schema = StructType.create();
        List<StructField> structFields = _schema.getStructFields();
        List<Object> _data = new ArrayList<>();
        List<String> col_names = getColNames();
        for (int index : Indexes) {
            Class<?> clazz = getColType(index);
            _data.add(get(index, clazz));
            structFields.add(StructField.createStructField(col_names.get(index), clazz));
        }
        _schema.setStructFields(structFields);
        return createRow(_schema, _data);
    }

    public void setSchema(StructType schema) {
        this.schema = schema;
    }

    public void setData(List<Object> data) {
        this.data = data;
    }

    public StructType getSchema() {
        return schema;
    }

    public List<Object> getData() {
        return data;
    }

    public Row copy() {
        return new Row(schema, data);
    }

    @SuppressWarnings("all")
    public void printSchema() {
        StringBuffer schema_str = new StringBuffer();
        schema_str.append("schema" + "\n");
        for (StructField structField : schema.getStructFields()) {
            String type = structField.getName() + ": " +
                    structField.getDataType().toString().split(" ")[1];
            schema_str.append("   |-- ").append(type).append("\n");
        }
        System.out.println(schema_str.toString().trim());

    }

    @Override
    @SuppressWarnings("all")
    public String toString() {
        StringBuffer res = new StringBuffer();
        res.append("Row(");
        List<StructField> structFields = schema.getStructFields();
        for (int i = 0; i <= size() - 1; i++) {
            String index_name = structFields.get(i).getName();
            Object index_val = data.get(i);
            if (i < size() - 1)
                res.append(index_name).append("=").append(index_val).append(", ");
            else
                res.append(index_name).append("=").append(index_val);
        }
        res.append(")");
        return res.toString();
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Row row = (Row) o;
        return schema.equals(row.schema) && data.equals(row.data);
    }

    @Override
    public int hashCode() {
        return Objects.hash(schema, data);
    }

}
