package org.example.dataset;

import java.io.Serializable;
import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;

/**
 * Created with IntelliJ IDEA.
 *
 * @Author: HillHuang
 * @Date: 2021/10/15/11:34
 * @Description:
 */
public class StructType implements Serializable {

    private List<StructField> structFields;

    private StructType() {
        List<StructField> tmp = new ArrayList<>();
        setStructFields(tmp);
    }

    private StructType(List<StructField> structFields) {
        this.structFields = structFields;
    }

    public static StructType create() {
        return new StructType();
    }

    public static StructType createStructType(StructField... structFields) {
        List<StructField> structFields1 = new ArrayList<>(Arrays.asList(structFields));
        return new StructType(structFields1);
    }

    public static StructType createStructType(List<StructField> structFields) {
        List<StructField> structFields1 = new ArrayList<>(structFields);
        return new StructType(structFields1);
    }

    public static <T> StructType createStructType(Class<T> objType) {
        List<StructField> structFields = new ArrayList<>();
        Field[] fields = objType.getDeclaredFields();
        for (Field field : fields) {
            field.setAccessible(true);
            structFields.add(StructField.createStructField(field.getName(), field.getType()));
        }
        return createStructType(structFields);
    }

    public static StructType createStructType(String colName, Class<?> colType) {
        return createStructType(StructField.createStructField(colName, colType));
    }

    public static StructType createStructType(String[] colNameList, Class<?>... colTypes) {
        int length = colNameList.length;
        int length1 = colTypes.length;
        if (length1 != length) {
            throw new IllegalArgumentException("the length of colNameList should be equal to that of colTypes");
        }
        List<StructField> structFields = new ArrayList<>();
        for (int i = 0; i < length; i++) {
            String colName = colNameList[i];
            Class<?> colType = colTypes[i];
            structFields.add(StructField.createStructField(colName, colType));
        }
        return new StructType(structFields);
    }

    public static StructType createStructType(List<String> colNameList, List<Class<?>> colTypes) {
        return createStructType(colNameList.toArray(new String[0]), colTypes.toArray(new Class<?>[0]));
    }

    public StructType add(String newFieldName, Class<?> type) {
        List<StructField> res = new ArrayList<>(structFields);
        res.add(StructField.createStructField(newFieldName, type));
        return StructType.createStructType(res);
    }

    public StructType add(String[] newFieldNames, Class<?>... types) {
        List<StructField> res = new ArrayList<>(structFields);
        int length = newFieldNames.length;
        for (int i = 0; i < length; i++) {
            res.add(StructField.createStructField(newFieldNames[i], types[i]));
        }
        return StructType.createStructType(res);
    }

    public StructType merge(StructType other) {
        String[] newFieldNames = other.structFields.stream().map(StructField::getName).toArray(String[]::new);
        Class<?>[] types = other.structFields.stream().map(StructField::getDataType).toArray(Class<?>[]::new);
        return add(newFieldNames, types);
    }

    public StructType select(String... fieldNames) {
        List<StructField> res = new ArrayList<>();
        List<String> fieldNameList = Arrays.asList(fieldNames);
        for (StructField structField : structFields) {
            String fieldName = structField.getName();
            if (fieldNameList.contains(fieldName)) {
                res.add(structField);
            }
        }
        return StructType.createStructType(res);
    }

    public StructType remove(String... fieldNames) {
        List<StructField> res = new ArrayList<>();
        List<String> fieldNameList = Arrays.asList(fieldNames);
        for (StructField structField : structFields) {
            String fieldName = structField.getName();
            if (!fieldNameList.contains(fieldName)) {
                res.add(structField);
            }
        }
        return StructType.createStructType(res);
    }

    //获取所有列的列名list
    public List<String> getColNames() {
        return structFields.stream().map(StructField::getName).collect(Collectors.toList());
    }

    //获取所有列的类型list
    public List<Class<?>> getColClasses() {
        return structFields.stream().map(StructField::getDataType).collect(Collectors.toList());
    }

    public List<StructField> getStructFields() {
        return structFields;
    }

    public void setStructFields(List<StructField> structFields) {
        this.structFields = structFields;
    }

    public void setStructFields(StructField... structFields) {
        this.structFields.addAll(Arrays.asList(structFields));

    }

    @Override
    @SuppressWarnings("all")
    public String toString() {
        StringBuffer res = new StringBuffer();
        res.append("StructType(");
        List<StructField> structFields = getStructFields();
        int size = structFields.size();
        for (int i = 0; i <= size - 1; i++) {
            StructField structField = structFields.get(i);
            String name = structField.getName();
            String clazz = structField.getDataType().toString().split(" ")[1];
            ;
            if (i < size - 1) {
                res.append(name).append(":").append(clazz).append(", ");
            } else {
                res.append(name).append(":").append(clazz);
            }
        }
        res.append(")");
        return res.toString();
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }
        StructType that = (StructType) o;
        if (structFields.size() != that.structFields.size()) {
            return false;
        }
        for (int i = 0; i < structFields.size(); i++) {
            if (!structFields.get(i).equals(that.structFields.get(i))) {
                return false;
            }
        }
        return true;
    }

    @Override
    public int hashCode() {
        return Objects.hash(structFields);
    }

}
