package org.example.model;

import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.io.Serializable;

/**
 * tuple2结构封装.
 */
@Getter
@Setter
@NoArgsConstructor
@EqualsAndHashCode
public class Tuple2<T1, T2> implements Serializable {

    private T1 value1;
    private T2 value2;

    protected Tuple2(T1 value1, T2 value2) {
        this.value1 = value1;
        this.value2 = value2;
    }

    public void setValues(T1 value1, T2 value2) {
        setValue1(value1);
        setValue2(value2);
    }


    public T1 _1() {
        return getValue1();
    }

    public T2 _2() {
        return getValue2();
    }

    public static <T1, T2> Tuple2<T1, T2> of(T1 value1, T2 value2){
        return new Tuple2<>(value1, value2);
    }

    @Override
    public String toString() {
        return "Tuple2("
                + value1
                + ", " + value2
                + ")";
    }

}
